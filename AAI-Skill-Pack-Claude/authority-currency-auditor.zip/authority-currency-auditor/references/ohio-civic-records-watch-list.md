# Quarantined cache

This file is not current law.

The dated watch list was moved to
`aai-family-0.2.0/untrusted-cache/ohio-civic-records-watch-list.md`.

Use it only as a search hint for section numbers that a work product may
have omitted. Before a currency answer, run
`aai-cognitive-interface/family/scripts/refetch_untrusted_cache.py currency`.
Re-fetch each needed section from codes.ohio.gov or the official reporter
in this session. Pending-lookup rows stay unresolved until that fetch.

HARD CONSTRAINT: Ohio Rev. Code 149.43 is time-sensitive.
On or after 2026-09-07, do not cite the pre-effective text as current.
Re-fetch codes.ohio.gov section-149.43 and section-149.43/9-7-2026 first.
Cache is not law.
