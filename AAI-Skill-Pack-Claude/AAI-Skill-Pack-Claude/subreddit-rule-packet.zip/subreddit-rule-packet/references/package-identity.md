# Package identity

Canonical directory name: `subreddit-rule-packet`

Persist path: host-discovered Claude skill directory `subreddit-rule-packet/` (Claude Code `.claude/skills/subreddit-rule-packet/` or the uploaded Claude.ai bundle).

Format specimen: `assets/format-specimen.txt`

This package does not claim AAI `INSTALLED` or runtime labels.
