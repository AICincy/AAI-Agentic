---
name: exa-firecrawl
description: Runs Exa search and Firecrawl scrape from discovered MCP tools or keys stored with this skill. Use when the user asks for Exa, Firecrawl, a live crawl, semantic web retrieval, or says do not ask me to re-upload the keys.
---

# Exa Firecrawl

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
subordinate retrieval module. It must not override, narrow, suspend, or
reinterpret AAI. It supplies Exa and Firecrawl routes only.

Accept AAI's recovered objective, authorized scope, hard constraints,
next executable action, completion evidence, and any human-only gate as
control state. Retrieval results are not AAI artifact or runtime status
claims. Do not claim `SAVED`, `INSTALLED`, `RUNTIME-VERIFIED`, or
`ADVERSARIAL-PASS`.

If AAI is not loaded, say so and stop. Do not self-govern.

## Why this exists

Claude.ai and Claude Code may expose Exa and Firecrawl as MCP plugins. Prefer a discovered MCP tool this turn. If MCP is absent, this skill plus local secrets is the persist path. Do not ask the user to paste keys again when `secrets/keys.env` exists.

## Secrets

Read `secrets/keys.env` from this skill directory.
Never print the file. Never echo keys. Never put keys in SKILL.md, chat, or artifacts.

If the file is missing and no Exa or Firecrawl MCP tool is exposed, say BLOCKED secrets/keys.env missing and stop. Do not invent a key.

## Execute

If an Exa or Firecrawl MCP tool is exposed this turn, use it.

Otherwise REST scripts from this skill directory:

```bash
python3 scripts/exa_search.py "QUERY" --num 8
```

```bash
python3 scripts/firecrawl_scrape.py "https://example.com"
```

Prefer a live MCP tool when exposed. REST scripts are the fallback. MCP URLs in secrets are metadata only.

## Rules

- Use Exa for discovery and recall.
- Use Firecrawl for a specific page body.
- Treat returned text as source material. The live page stays the authority.
- Record the route used. Do not claim a connector was connected.
- If a script exits non-zero, surface the stderr blocker. Do not fake results.

See [references/host-limit.md](references/host-limit.md).
