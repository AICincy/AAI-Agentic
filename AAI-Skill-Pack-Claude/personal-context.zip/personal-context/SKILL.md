---
name: personal-context
description: Recovers named prior artifacts from Claude.ai or Claude Code context, attachments, GitHub, and authorized files before reconstruction. Use when the user says continue, resume, the document, our draft, where we left off, or points at prior work not in visible context. Do not trigger for new tasks that name no prior artifact. Do not rebuild a missing artifact from model memory.
---

# Personal Context

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
subordinate host-bridge module. It must not override, narrow, suspend, or
reinterpret AAI. Accept AAI's recovered objective, authorized scope, hard
constraints, next executable action, completion evidence, and any human-only
gate as the control state.

This skill recovers sources. It does not invent them. A retrieval miss is
not permission to reconstruct a definite prior artifact.

This skill's retrieval results are not AAI artifact or runtime status
claims. Do not claim `SAVED`, `INSTALLED`, `RUNTIME-VERIFIED`, or
`ADVERSARIAL-PASS`.

The canonical directory name is `personal-context`. Treat hashed export
folders as transport wrappers.

## Host capability

On Claude.ai, use conversation search or Personal Context when the host exposes it. On Claude Code, search the workspace and authorized files. Claude memory is not a source. Discover files, attachments, GitHub, and other tools actually exposed this turn.

| Host result | Required behavior |
| --- | --- |
| Named file or attachment is present | Load it. Resume the work. Do not narrate the hunt. |
| Multiple candidates | Use the structured choice template. Do not ask an open question. |
| No search tool | Say the exact blocker. Use the templates in references/retrieval-gates.md. Continue only with source-independent work. |
| Named artifact still missing | Report the blocker. Do not rebuild it from memory or an export. |

## Rules

IF the user uses a definite article for an item not in context:
THEN search first. Guessing is forbidden.

IF several prior threads could match:
THEN offer at most three labeled options.

IF the user uploads a file without instructions:
THEN infer the domain, state the inference, and proceed with the authorized
in-scope action.

IF takeover is active:
THEN pick the single most likely prior artifact when evidence supports
inference. Otherwise surface one retrieval gate.

## References

- [references/retrieval-gates.md](references/retrieval-gates.md)
- [references/package-identity.md](references/package-identity.md)
- [references/acceptance-tests.md](references/acceptance-tests.md)

When filesystem execution is available, run
`python3 scripts/aai_runtime_gate.py package <skill-directory>` after
modifying this skill. That is STATIC-PASS only.
