---
name: amex-subreddit-ops
description: Retired redirect. Use reddit-owner-ops for r/Amex AutoMod, referral thread, community-karma floor, 1a 1b 1e, or owner ops. Do not author artifacts from this package.
---

# Amex Subreddit Ops (retired)

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
retired subordinate stub. It must not override, narrow, suspend, or
reinterpret AAI.

Accept authorized scope, hard constraints, completion evidence, and status
claims from `reddit-owner-ops`. Redirect only. Do not claim `INSTALLED`.

IF this skill is invoked
THEN keep `aai-cognitive-interface` as governor and load
`reddit-owner-ops/SKILL.md` from the Gemini skills root. Execute that package
under AAI. Do not draft AutoMod, mail, or packet text from this file.
Do not self-govern from this stub.
