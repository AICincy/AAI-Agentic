# Package identity

Canonical directory name: `amex-subreddit-ops`

Retired redirect. Authoring package is `reddit-owner-ops`.
This stub does not claim AAI INSTALLED or runtime labels.
