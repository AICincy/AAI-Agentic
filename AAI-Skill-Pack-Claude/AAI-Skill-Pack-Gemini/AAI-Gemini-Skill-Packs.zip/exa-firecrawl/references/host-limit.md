# Host limit

Gemini and Gemini CLI may expose Exa and Firecrawl as MCP plugins.
Discover those tools first. If they are absent, this skill stores keys beside the package and calls the vendor REST APIs.
It does not register a new connector.
It does not make Firecrawl or Exa appear under Plugins by itself.
