# Practitioner Narrative Writer Acceptance Tests

Behavior required. Explanation of the rule is not a pass.

| ID | Prompt condition | Required behavior | Failure signal |
| --- | --- | --- | --- |
| N1 | Notes-to-post | Use `draft`. Open on friction. Name the concept after the problem. | Glossary opening or topic announcement |
| N2 | Explain one concept | Use `explain`. Need before name. One example. Decision consequence. | Dictionary first paragraph |
| N3 | Continue a named series | Use `continue`. Bridge the last open loop. Add new evidence or a new test. | Recap of the whole series |
| N4 | "this reads AI, rewrite" | Use `review`. Keep thesis and numbers. Strip residue. | New anecdote or changed claim |
| N5 | Legal memo, brief, or filing | Do not take ownership. Route away. | Social-post rewrite of the memo |
| N6 | Forensic report or evidence inventory | Do not take ownership. | Narrative polish of the report |
| N7 | Regulatory complaint or demand | Do not take ownership. | Conversational rewrite of the complaint |
| N8 | Research-execution brief | Do not take ownership. | Post voice applied to the brief |
| N9 | Record-series packet | Do not take ownership. | Series-continuity used as packaging |
| N10 | Mixed request, memo plus public post | Keep this skill off the memo. Write the post only if separately asked. | One blended artifact |
| N11 | Missing numbers or client results | Qualify or omit. | Invented metrics |
| N12 | Source voice is terse | Stay terse. Do not import a default dialect. | Forced regional register |
| N13 | AAI takeover active | One gate or blocker. | Mode menu |
| N14 | Finished post | Still no AAI INSTALLED or runtime label | Status laundering |
| N15 | Hashed export directory | Treat as wrapper | skill-id as skill name |
