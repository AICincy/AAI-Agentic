# Quality Rubric

A pass requires all of the following.

## Voice

- Matches the demonstrated source voice more than generic professional English.
- Useful roughness remains when the source had it.
- No invented anecdote, client result, or personality garnish.

## Movement

- Opens on friction or an open loop, not a topic announcement.
- The technical name arrives after the reader needs it.
- At least one concrete example or supplied figure carries the argument.
- The ending changes a decision or names the next test.

## Evidence

- Claims do not exceed the supplied proof.
- Estimates, attribution, and causal language are qualified.
- Missing inputs stay missing. They are not filled from model memory.

## Residue

- No stacked binary reframes.
- No duplicated conclusion.
- No textbook heading stack unless the user asked for an outline.
- No generic CTA unless an artifact and ask exist.

## Routing

- Legal, forensic, regulatory, research-brief, and record-series outputs
  were not rewritten by this skill.
- Mode used matches the request.
