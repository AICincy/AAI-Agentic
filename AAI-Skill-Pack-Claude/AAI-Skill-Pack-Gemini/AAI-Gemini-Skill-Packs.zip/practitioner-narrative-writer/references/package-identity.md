# Package Identity

| Field | Value |
| --- | --- |
| Skill name | practitioner-narrative-writer |
| Directory name | practitioner-narrative-writer |
| Role | Subordinate domain module |
| Governor | aai-cognitive-interface |
| Version file | ../VERSION |

A hashed export folder such as `skill-<id>/` is a transport wrapper. Validate and install from `practitioner-narrative-writer/`.

This package may claim STATIC-PASS only after:

```
python3 scripts/aai_runtime_gate.py package <this-directory>
```

returns `status: PASS` in `package-skill` mode.

Writing-mode labels are not AAI artifact statuses. A finished post does not prove SAVED, INSTALLED, or any runtime label.
