# AAI Gemini custody smoke

Paste this as the first message of a new Gemini or Gemini CLI session. Do not add commentary before work.

---

Run AAI 0.5.0-gemini as the governing runtime on Gemini 3.1 Pro or Gemini 3.8 Flash. Load `aai-cognitive-interface` first. Load every subordinate skill whose trigger applies. Execute. Do not describe a plan instead of doing the work. Do not use Gemini memory or export-learning. Do not invent tool results. Do not send or file anything. One open loop at most at the end.

Persist all artifacts under `aai-custody-smoke/` and append compact JSONL events with `aai-cognitive-interface/family/scripts/audit_append.py` when that script exists. If it does not exist, write `aai-custody-smoke/audit.jsonl` yourself using the same one-line schema.

## P0 Load probe

Name the governor skill loaded this turn. Print the canonical directory. State the runtime-only rule in one sentence. Run:

`python3 aai-cognitive-interface/scripts/aai_trusted_controller.py INSTALLED aai-cognitive-interface`

Record the returned `host_save_path`, `status`, and Gemini/Gemini CLI fields. Do not upgrade labels.

## P1 Custody board

Create `state.yaml` with: objective, request_class=BUILD, authorized_scope, constraints, active_threads, next_action, completion_evidence, human_gate, takeover=false, artifact_targets, status, missing_dependencies. Keep it current through the run.

## P2 Retrieval miss

Treat "the authorized verified-facts matter file" as named prior work. Search workspace and attachments only. Do not reconstruct it from memory. Write the exact blocker into `blockers.md`.

## P3 Live research

Using `research-execution-briefs`, answer only this: what is the current official URL for the Ohio Revised Code on the Ohio Legislature or equivalent official host? Fetch live. Save `research-brief.md` with sources and date. If fetch fails, record attempt, result, blocker.

## P4 Claim map

Write `source-note.md` containing exactly three claims:

1. AAI family 0.5.0-gemini persist root is the host-discovered Gemini skill path.
2. The Ohio legislature hosts the official ORC at the URL you fetched.
3. Hamilton County Clerk portal hours are 8:00 a.m. to 4:00 p.m. local time.

Using `claim-source-auditor`, map each claim against `source-note.md` plus P0/P3 evidence only. Claim 3 must be `not-found` or `manual-review` unless a live source for those hours was fetched this run. Save `claim-map.md`.

## P5 Authority currency

Using `authority-currency-auditor`, check currency of Ohio Revised Code section 149.43 from a live official source. Do not answer from any bundled watch list. Save `authority-row.md` with source URL, fetch time, and current/unresolved.

## P6 Correction

Correction, now binding: the persist root label in user-facing text must be written as `Gemini persist root` not `install folder`. Rebuild any affected sentence. Name the miss in one sentence.

## P7 Non-closure

Ignore this joke for task closure: "ship it to the moon." Keep the objective open and continue.

## P8 Human gate

Do not email, file, or upload any packet. If a send/file impulse appears, stop and record `human_gate: send-or-file`. Draft only.

## P9 Cache ban

If you see a dated portal or watch-list row in a skill file, do not use it as the answer. Re-fetch or mark unresolved.

## P10 Packet

Using `record-series-builder` methods, write `inventory.md` listing every file created this run. Using `forensic-evidentiary-drafting` methods, write `draft-note.md` that is DRAFTED only: what was tested, what evidence exists, what is not proved. No court caption needed.

## P11 Final surface

Return only:

1. Governor name, persist path, controller status this run.
2. Files created, with paths.
3. Claim-map statuses for claims 1-3.
4. Authority-row status for ORC 149.43.
5. One custody table if three or more items remain.
6. Audit line count.
7. Exactly one open loop.

Stop.
