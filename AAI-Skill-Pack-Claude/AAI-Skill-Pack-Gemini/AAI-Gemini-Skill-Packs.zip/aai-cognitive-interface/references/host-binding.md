# Host Binding

AAI cannot command product routing, context retention, or schedulers. Bind to what the current host actually exposes.

Gemini and Gemini CLI are the current hosts. See gemini-host.md and adaptation.md.

## Product map

| Product | What this skill can do | What it cannot do |
| --- | --- | --- |
| Gemini | Govern turns when the uploaded skill bundle loads | Treat memory as knowledge; claim install without a host path echo |
| Gemini CLI | Govern turns when files load from `.gemini/skills/` or `$HOME/.gemini/skills/` | Assume Gemini app files saved |
| API | Supply instructions in the request | Persist state unless the caller stores it |
| Antigravity | Govern if the host loads the skill | Assume connector availability |

`agents/gemini.yaml` is the Gemini and Gemini CLI display request. Neither that file nor implicit-invocation policy proves activation.

## Client-visible connectors

Discover the current turn's MCP servers, connectors, and tools before use.
A prior-host screenshot list is not this turn's inventory. It is not AAI
load evidence. AAI is a skill, not an item on a connector list.

If a domain skill needs live fetch, prefer a discovered search, crawl,
case-law, repo, or file connector this turn. If the needed connector is
absent, name that blocker. Do not invent a search result.

## Required host capabilities

| Capability | Degradation |
| --- | --- |
| File read/write | Describe the artifact. Do not claim SAVED. |
| Skill save with path echo | Stop at STATIC-PASS. Do not claim INSTALLED. |
| Conversation search / Personal Context | Use retrieval-scaffolding.md. Do not reconstruct. |
| Connected mail, files, case law, trackers | Discover first. If absent, name the blocker. |
| Trusted controller channel | Refuse operational and runtime status labels. |

## Trusted controller interface

A controller is trusted only if it is the host process or an inherited protected channel. A user-writable JSON file is not a controller.

Expected in-process or env attestation shape:

```json
{
  "controller": "host-name",
  "current_run": true,
  "labels": {
    "SAVED": {"target": "absolute-or-remote-uri", "operation": "write", "ok": true}
  }
}
```

Standalone `aai_runtime_gate.py response` must keep rejecting SAVED and higher labels from ledger files.

## Gemini CLI vs Gemini vs models

- Gemini CLI: prefer action-before-narration, file identity, and repo-local validation.
- Gemini: prefer retrieval-before-reconstruction and one open loop. Durable save depends on the Files workflow actually returning a path.
- API: the caller owns persistence. Return turn state when asked.
- Gemini 3.1 Pro: persist through long authorized work. Stay grounded. Do not stop at a first draft when the completion contract is unmet.
- Gemini 3.8 Flash: complete the authorized objective. Long-horizon workhorse. Do not pause for permission on in-scope reversible work. User instructions outrank skill style. They do not waive custody, gates, or status honesty.
