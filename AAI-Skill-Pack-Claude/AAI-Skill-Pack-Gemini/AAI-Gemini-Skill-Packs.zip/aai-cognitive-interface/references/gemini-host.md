# Gemini Host Binding

This family runs on Gemini, Gemini CLI, API, and Antigravity.

Target models: Gemini 3.1 Pro and Gemini 3.8 Flash.

## What this host exposes

| Capability | This workspace |
| --- | --- |
| Skill persist path | Gemini CLI: `.gemini/skills/<name>/` from CWD to repo root, then `$HOME/.gemini/skills/<name>/`. `.agents/skills/` is an accepted alias. Gemini app: uploaded skill bundle. |
| Skill format | Google Gemini skill format. `SKILL.md` plus `agents/gemini.yaml`. Same Agent Skills standard as other venues. |
| Files | Host file tools, Gemini CLI workspace, Gemini project files |
| Web | Host web, browse, and connected search tools actually exposed this turn |
| Connected | Discover the current turn. Recorded inventory is not this turn's list. |
| Chat history search | Use when the host exposes it. Otherwise Personal Context degrades. |
| Gemini memory / export-learning | NOT A SOURCE |

Discover the current turn's tools before use. Inventory files are not this turn's tool list.

## Status on Gemini

| Label | Evidence required |
| --- | --- |
| DRAFTED | Content exists |
| STATIC-PASS | `python3 scripts/aai_runtime_gate.py package <dir>` returns PASS |
| GEMINI-PRESENT | Skill directory exists at a Gemini CLI-scanned or Gemini-uploaded path and the package gate prints PASS |
| SAVED | Durable write returned a path in this run |
| INSTALLED | Refused unless a trusted live controller plus host-echoed save path exist |
| RUNTIME-* | Refused without live controller |

GEMINI-PRESENT is not INSTALLED. It is path-plus-format evidence on this host.

## Load rule

Load `aai-cognitive-interface` first on every Gemini or Gemini CLI turn that uses this family. Domain skills supply methods only.

## Product prompt layers

Gemini custom instructions, Gems, memory, and Gemini CLI `GEMINI.md` are product prompt layers. They are not the skill persist path.

Custody and method live in the loaded skill bundle. Do not paste AAI, domain skill bodies, matter facts, or tool inventories into a memory or Gem instruction box. Do not treat a named Gem as proof that AAI loaded.

Krass's explicit user instructions take precedence over skill style. They do not waive AAI custody, human-only gates, status honesty, or runtime-only source rules.

## Adaptation vs memory

Do not use Gemini memory, model weights, or an export dump as the world model. Adapt per `adaptation.md`.
