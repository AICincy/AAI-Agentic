#!/usr/bin/env python3
"""Confirm the 0.5.0-gemini family is present and usable on this host."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

def discover_skills_root(anchor: Path) -> Path:
    """Locate the sibling skills directory for this Gemini venue."""
    for start in [anchor, *anchor.parents]:
        if (start / "aai-cognitive-interface" / "SKILL.md").is_file():
            return start
        if start.name == "aai-cognitive-interface" and (start / "SKILL.md").is_file():
            parent = start.parent
            if (parent / "aai-cognitive-interface" / "SKILL.md").is_file():
                return parent
    cwd = Path.cwd()
    for base in [cwd, *cwd.parents, Path.home()]:
        for rel in (Path(".gemini") / "skills", Path("skills")):
            cand = base / rel
            if (cand / "aai-cognitive-interface" / "SKILL.md").is_file():
                return cand
    home = Path.home() / ".gemini" / "skills"
    if (home / "aai-cognitive-interface" / "SKILL.md").is_file():
        return home
    return Path.cwd() / ".gemini" / "skills"


HERE = Path(__file__).resolve()
ROOT = discover_skills_root(HERE)
GATE = ROOT / "aai-cognitive-interface" / "scripts" / "aai_runtime_gate.py"
SKILLS = [
    "aai-cognitive-interface",
    "personal-context",
    "register-mediation",
    "authority-currency-auditor",
    "claim-source-auditor",
    "forensic-evidentiary-drafting",
    "prompt-architecture-engineering",
    "record-series-builder",
    "regulatory-complaint-drafting",
    "research-execution-briefs",
]


def main() -> int:
    rows = []
    failed = []
    for name in SKILLS:
        path = ROOT / name
        if not path.is_dir() or not (path / "SKILL.md").is_file():
            rows.append({"skill": name, "status": "ABSENT"})
            failed.append(name)
            continue
        aai = subprocess.run(
            [sys.executable, str(GATE), "package", str(path)],
            text=True,
            capture_output=True,
            check=False,
        )
        gemini_yaml = (path / "agents" / "gemini.yaml").is_file()
        ok = aai.returncode == 0 and gemini_yaml
        rows.append(
            {
                "skill": name,
                "status": "GEMINI-PRESENT" if ok else "FAIL",
                "path": str(path),
            }
        )
        if not ok:
            failed.append(name)
    payload = {
        "host": "gemini",
        "claim": "GEMINI-PRESENT" if not failed else "PARTIAL",
        "installed_claim": "REFUSED",
        "failed": failed,
        "results": rows,
    }
    print(json.dumps(payload, indent=2))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
