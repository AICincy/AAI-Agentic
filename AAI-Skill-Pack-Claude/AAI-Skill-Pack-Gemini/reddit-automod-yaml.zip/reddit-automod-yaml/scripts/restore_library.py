#!/usr/bin/env python3
"""Copy the persisted AutoMod library into ./artifacts."""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'assets' / 'library'
DEST = Path.cwd() / "artifacts"
FILES = [
    "r-amex-automod-0.1.3.yml",
    "r-amex-automod-0.1.3.2.yaml",
    "r-amex-automod-0.1.3.3.yaml",
    "r-amex-automod-0.1.3.4.yaml",
    "r-amex-automod-0.1.3.4-public-copy.md",
    "r-amex-unpublished-tokens.txt",
    "amex-ops-state.yaml",
]


def main() -> int:
    if not SRC.is_dir():
        print(f"FAIL missing {SRC}")
        return 2
    DEST.mkdir(parents=True, exist_ok=True)
    copied = []
    missing = []
    for name in FILES:
        src = SRC / name
        if not src.is_file():
            missing.append(str(src))
            continue
        dest = DEST / name
        shutil.copy2(src, dest)
        copied.append(str(dest))
    # also expose base 0.1.3 under the attachments-style name in artifacts
    base = DEST / "r-amex-automod-0.1.3.yml"
    attach = Path.cwd() / "attachments"
    attach.mkdir(parents=True, exist_ok=True)
    if base.is_file():
        shutil.copy2(base, attach / "0.1.3.yml")
        copied.append(str(attach / "0.1.3.yml"))
    print("copied", len(copied))
    for p in copied:
        print(p)
    if missing:
        print("missing_src", missing)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
