# Package identity

Canonical directory name: `reddit-owner-ops`

Persist path: host-discovered OpenAI skill directory `reddit-owner-ops/` (Codex `.agents/skills/reddit-owner-ops/` or the uploaded ChatGPT bundle).

Retired predecessor: `amex-subreddit-ops`

This package does not claim AAI `INSTALLED` or runtime labels.

Live floors, thread IDs, roster permission bits, and queue counts are not
package identity. They belong in operator state outside this skill.
