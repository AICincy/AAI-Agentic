# Package identity

Canonical directory name: `subreddit-rule-packet`

Persist path: host-discovered OpenAI skill directory `subreddit-rule-packet/` (Codex `.agents/skills/subreddit-rule-packet/` or the uploaded ChatGPT bundle).

Format specimen: `assets/format-specimen.txt`

This package does not claim AAI `INSTALLED` or runtime labels.
