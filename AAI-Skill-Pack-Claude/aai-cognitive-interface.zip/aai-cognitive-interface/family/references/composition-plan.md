# Composition plan

Mediation-layer object. Not an agent.

Schema: `family/schemas/composition-plan.schema.json`
Writer: `family/scripts/write_composition_plan.py`
Instance: `family/state/composition-plan.json`

Write a plan at the start of a multi-skill turn. First skill is always `aai-cognitive-interface`.

On Claude.ai and Claude Code, discover whether a spawn tool is present this turn. If it is not, `spawn_tool_present` is false and mode must be `compose-skills`.

Contract lives here and in AAI `references/composition-map.md`.
Do not copy the schema into every domain SKILL.md.
