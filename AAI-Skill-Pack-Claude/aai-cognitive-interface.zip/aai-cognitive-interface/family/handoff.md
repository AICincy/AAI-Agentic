# Handoff: AAI family current

Date: 2026-09-03
Updated: 2026-09-09 14:22 EDT
Operator: Krass
Governor: aai-cognitive-interface
Family label: 0.3.0
Anthropic persist: STATIC-PASS after gate. INSTALLED only if the trusted
controller returns INSTALLED this run. Scope is anthropic-persist-only.
Runtime labels: not claimed. Not RUNTIME-VERIFIED. Not ADVERSARIAL-PASS.

AAI is an accessibility overlay on whatever model is running. Skills are
runtimes. They hold control, not a world model. Live host actions that
can run are run. Simulated results are forbidden. Failures are never
silent.

## Bundle

Authoritative persist path on this host:

Claude Code `.claude/skills/` or the Claude.ai uploaded skill bundle.

Family files: `aai-cognitive-interface/family/`
Stale and do not use: `aai-family-current-2026-09-03.zip`,
`artifacts/send-resend-email.sh`.

Newest deliverable this turn:

- prior-host `artifacts/handoff.zip`
- `aai-cognitive-interface/family/first-message-execution.md`

## How to execute

1. Load `aai-cognitive-interface` first.
2. Load `family/composition-catalog.md` and this file.
3. Paste `first-message-execution.md` as the first user message on a new turn if custody must be re-established.
4. Run `python3 aai-cognitive-interface/family/scripts/validate_family.py` from the skills root.
5. Pick exposed connectors from `references/connector-routing.md`.
   Krass does not name plugins except at send/file gates.
6. Authorized Resend work runs in the same turn through `resend-api` scripts.
   Do not spawn agents. Do not print `secrets/keys.env`.
7. On host interrupt, park state with register-mediation.
8. Stop at one open loop.

## Packages

| Skill | Role | Anthropic venue pack 2026-09-11 |
| --- | --- | --- |
| aai-cognitive-interface | Governor overlay | STATIC-PASS |
| personal-context | Retrieval gates | STATIC-PASS |
| register-mediation | Waiting room | STATIC-PASS |
| authority-currency-auditor | Authority currentness methods | STATIC-PASS |
| claim-source-auditor | Claim-to-source methods | STATIC-PASS |
| forensic-evidentiary-drafting | Court draft methods | STATIC-PASS |
| prompt-architecture-engineering | Instruction-contract methods | STATIC-PASS |
| practitioner-narrative-writer | Practitioner social-post methods | STATIC-PASS |
| record-series-builder | Volume packet methods | STATIC-PASS |
| regulatory-complaint-drafting | Agency draft methods | STATIC-PASS |
| research-execution-briefs | Research-chain methods | STATIC-PASS |
| reddit-owner-ops | Subreddit owner-ops methods | STATIC-PASS |
| subreddit-rule-packet | Public rule packet methods | STATIC-PASS |
| resend-api | Authorized Resend HTTP methods | STATIC-PASS |
| aai-cognitive-interface/family | Catalog, state, cache, validator | persist path |

`amex-subreddit-ops` is a retired redirect only. Load `reddit-owner-ops`.
`exa-firecrawl` is present as a host-bridge. It was not in the 2026-09-09
controller batch.

Absent: frontend-design, strategic-brief-architect-style, filled matter
file, Claude.ai/Claude Code install-path echo.

## Closed this session

| Item | State |
| --- | --- |
| Runtime-only overlay | Closed. Dated tables are untrusted cache. |
| Quarantine of watch list, Hamilton County snapshot, recipient matrix | Closed. Stubs in skills. Bodies in untrusted-cache/. |
| Shared gate | Closed. Canonical file under AAI. |
| Anthropic venue pack | Closed 2026-09-11. Claude skill format. Claude Sonnet 4.6, Opus 5, Sonnet 5, Opus 4.7, and Opus 4.8. AAI remains governor. |
| resend-api wiring | Closed. Subordinate contract, composition-map, catalog, routing eval, same-turn tool action. |
| First live Resend send | Closed. id `0bb1115f-39cd-4e5e-a186-0beaba90f40e` sent and delivered 2026-09-09 2:13 PM to jaredcincy@gmail.com. Key is send-only. |
| Stale artifact sender and MCP dump | Removed. |
| Waiting-room persist | Closed. state/waiting-room-state.json. |
| Connector inventory | Closed as client-visible list. Not AAI load evidence. |
| Autonomous connector pick | Closed as rule. Execute if exposed. |
| No silent failure | Closed as rule. |
| Live execution / no theater | Closed as rule. |

## Still open

| Item | State |
| --- | --- |
| Matter file | WAITING on Krass export. Do not fill from memory. |
| Host activation | NOT-OBSERVED on Claude.ai/Claude Code. Missing logs are not a finding. |
| Live re-fetch of quarantined rows | Not done. Re-fetch when a filing or send path is authorized. |
| Claude.ai / Claude Code install | Not performed from this workspace. |
| Resend retrieve/list | BLOCKED on stored send-only key (`401 restricted_api_key`). |
| Further live Resend send | Human gate unless Krass authorizes the exact send. |

## Capacity

Can: keep custody; park a turn; rewrite form once; pick exposed
connectors; research; map claims; check live authorities; draft; pack
files; send authorized Resend mail through local scripts; degrade with
a notice.

Cannot: search chat history without a host tool; file or clerk-upload;
attest Claude.ai/Claude Code INSTALLED; treat cache as law; invent a tool
result; intercept a pre-model drop; change host guardrails; observe
Anthropic telemetry; print the Resend key.

## First command

```
python3 aai-cognitive-interface/family/scripts/validate_family.py
```

## Next authorized action

Wait for the matter export, a full-access Resend key, or an authorized
next send. One only.
