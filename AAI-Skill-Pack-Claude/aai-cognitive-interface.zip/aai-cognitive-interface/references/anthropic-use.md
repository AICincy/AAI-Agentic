# Anthropic Use

These skills are Claude.ai and Claude Code skills. Package each as its own zip with a top-level folder matching `name`.

On every Claude.ai or Claude Code turn with this family present:

1. Load aai-cognitive-interface first.
2. Load personal-context only if prior work is named.
3. Load every domain skill whose description trigger matches.
4. Execute. Do not describe the skill instead of using it.
5. Append one audit line after a gate, block, adapt, or three-plus tool steps.

Persist path is the install location on this host. CLAUDE-PRESENT means the directory exists at a Claude Code-scanned or Claude.ai-uploaded path and the package gate passes. INSTALLED stays refused without a trusted controller.

Claude Opus 5: persist until the completion contract is met.
Claude Opus 4.8: keep long-running consistency. Do not stop at a first implementation.
Claude Opus 4.7: stay thorough on difficult work. Do not skip verification.
Claude Sonnet 5: complete the authorized objective before returning. Load references only when the current task needs them.
Claude Sonnet 4.6: stay lean and outcome-focused. Point to supporting files instead of forcing a full read.

Family files live at `family/` inside this skill so the catalog and audit log travel with the governor.
