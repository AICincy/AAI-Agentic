# Anthropic Host Binding

This family runs on Claude.ai, Claude Code, API, and Cowork.

Target models: Claude Sonnet 4.6, Opus 5, Sonnet 5, Opus 4.7, and Opus 4.8.

## What this host exposes

| Capability | This workspace |
| --- | --- |
| Skill persist path | Claude Code: `.claude/skills/<name>/` from CWD to repo root, then `$HOME/.claude/skills/<name>/`. Claude.ai: uploaded skill bundle. |
| Skill format | Anthropic Claude skill format. `SKILL.md` plus `agents/anthropic.yaml`. |
| Files | Host file tools, Claude Code workspace, Claude project files |
| Web | Host web, browse, and connected search tools actually exposed this turn |
| Connected | Discover the current turn. Recorded inventory is not this turn's list. |
| Chat history search | Use when the host exposes it. Otherwise Personal Context degrades. |
| Claude memory / export-learning | NOT A SOURCE |

Discover the current turn's tools before use. Inventory files are not this turn's tool list.

## Status on Anthropic

| Label | Evidence required |
| --- | --- |
| DRAFTED | Content exists |
| STATIC-PASS | `python3 scripts/aai_runtime_gate.py package <dir>` returns PASS |
| CLAUDE-PRESENT | Skill directory exists at a Claude Code-scanned or Claude.ai-uploaded path and the package gate prints PASS |
| SAVED | Durable write returned a path in this run |
| INSTALLED | Refused unless a trusted live controller plus host-echoed save path exist |
| RUNTIME-* | Refused without live controller |

CLAUDE-PRESENT is not INSTALLED. It is path-plus-format evidence on this host.

## Load rule

Load `aai-cognitive-interface` first on every Claude.ai or Claude Code turn that uses this family. Domain skills supply methods only.

## Product prompt layers

Claude project instructions, memory, and Claude Code `CLAUDE.md` are product prompt layers. They are not the skill persist path.

Custody and method live in the loaded skill bundle. Do not paste AAI, domain skill bodies, matter facts, or tool inventories into a memory or custom-instruction box. Do not treat a named Claude Project as proof that AAI loaded.

Krass's explicit user instructions take precedence over skill style. They do not waive AAI custody, human-only gates, status honesty, or runtime-only source rules.

## Adaptation vs memory

Do not use Claude memory, model weights, or an export dump as the world model. Adapt per `adaptation.md`.
