# Host Binding

AAI cannot command product routing, context retention, or schedulers. Bind to what the current host actually exposes.

Claude.ai and Claude Code are the current hosts. See anthropic-host.md and adaptation.md.

## Product map

| Product | What this skill can do | What it cannot do |
| --- | --- | --- |
| Claude.ai | Govern turns when the uploaded skill bundle loads | Treat memory as knowledge; claim install without a host path echo |
| Claude Code | Govern turns when files load from `.claude/skills/` or `$HOME/.claude/skills/` | Assume Claude.ai files saved |
| API | Supply instructions in the request | Persist state unless the caller stores it |
| Cowork | Govern if the host loads the skill | Assume connector availability |

`agents/anthropic.yaml` is the Claude.ai and Claude Code display request. Neither that file nor implicit-invocation policy proves activation.

## Client-visible connectors

Discover the current turn's MCP servers, connectors, and tools before use.
A prior-host screenshot list is not this turn's inventory. It is not AAI
load evidence. AAI is a skill, not an item on a connector list.

If a domain skill needs live fetch, prefer a discovered search, crawl,
case-law, repo, or file connector this turn. If the needed connector is
absent, name that blocker. Do not invent a search result.

## Required host capabilities

| Capability | Degradation |
| --- | --- |
| File read/write | Describe the artifact. Do not claim SAVED. |
| Skill save with path echo | Stop at STATIC-PASS. Do not claim INSTALLED. |
| Conversation search / Personal Context | Use retrieval-scaffolding.md. Do not reconstruct. |
| Connected mail, files, case law, trackers | Discover first. If absent, name the blocker. |
| Trusted controller channel | Refuse operational and runtime status labels. |

## Trusted controller interface

A controller is trusted only if it is the host process or an inherited protected channel. A user-writable JSON file is not a controller.

Expected in-process or env attestation shape:

```json
{
  "controller": "host-name",
  "current_run": true,
  "labels": {
    "SAVED": {"target": "absolute-or-remote-uri", "operation": "write", "ok": true}
  }
}
```

Standalone `aai_runtime_gate.py response` must keep rejecting SAVED and higher labels from ledger files.

## Claude Code vs Claude.ai vs models

- Claude Code: prefer action-before-narration, file identity, and repo-local validation.
- Claude.ai: prefer retrieval-before-reconstruction and one open loop. Durable save depends on the Files workflow actually returning a path.
- API: the caller owns persistence. Return turn state when asked.
- Claude Opus 5: persist through long authorized work. Do not stop at a first draft when the completion contract is unmet.
- Claude Opus 4.8: keep long-running consistency and autonomy.
- Claude Opus 4.7: stay thorough on difficult work. Do not skip verification.
- Claude Sonnet 5: complete the authorized objective. Do not pause for permission on in-scope reversible work. User instructions outrank skill style. They do not waive custody, gates, or status honesty.
- Claude Sonnet 4.6: stay lean and outcome-focused. Load references only when needed.
