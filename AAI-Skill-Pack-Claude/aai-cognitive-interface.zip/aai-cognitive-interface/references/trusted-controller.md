# Trusted Controller

On Claude.ai and Claude Code, the host save path is the loaded skill directory.
Claude Code scans `.claude/skills/<canonical-name>/` from CWD to repo root,
then `$HOME/.claude/skills/<canonical-name>/`. Claude.ai uses the uploaded
bundle path the host echoes.

Emit INSTALLED only when `scripts/aai_trusted_controller.py INSTALLED <name>`
returns status INSTALLED this run, with:

- directory present under the discovered persist root
- SKILL.md name matching the directory
- `aai_runtime_gate.py package` PASS
- `agents/anthropic.yaml` present

That label is anthropic-persist only.

RUNTIME-SMOKE-PASS, RUNTIME-VERIFIED, and ADVERSARIAL-PASS stay refused
until a separate live suite runs.
