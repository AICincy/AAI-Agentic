#!/usr/bin/env python3
"""Anthropic persist-path controller."""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

def discover_skills_root(anchor: Path) -> Path:
    """Locate the sibling skills directory for this Anthropic venue."""
    for start in [anchor, *anchor.parents]:
        if (start / "aai-cognitive-interface" / "SKILL.md").is_file():
            return start
        if start.name == "aai-cognitive-interface" and (start / "SKILL.md").is_file():
            parent = start.parent
            if (parent / "aai-cognitive-interface" / "SKILL.md").is_file():
                return parent
    cwd = Path.cwd()
    for base in [cwd, *cwd.parents, Path.home()]:
        for rel in (Path(".claude") / "skills", Path("skills")):
            cand = base / rel
            if (cand / "aai-cognitive-interface" / "SKILL.md").is_file():
                return cand
    home = Path.home() / ".claude" / "skills"
    if (home / "aai-cognitive-interface" / "SKILL.md").is_file():
        return home
    return Path.cwd() / ".claude" / "skills"


HERE = Path(__file__).resolve()
PERSIST = discover_skills_root(HERE)
GATE = PERSIST / "aai-cognitive-interface" / "scripts" / "aai_runtime_gate.py"
OPERATIONAL = {
    "INSTALLED",
    "RUNTIME-SMOKE-PASS",
    "RUNTIME-VERIFIED",
    "ADVERSARIAL-PASS",
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def fail(requested: str, reason: str, extra: dict | None = None) -> int:
    payload = {
        "requested": requested,
        "bound": False,
        "host": "anthropic",
        "status": "FAIL",
        "emitted_label": None,
        "checked_at": now(),
        "reason": reason,
    }
    if extra:
        payload.update(extra)
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 2


def verify_skill(name: str) -> tuple[bool, str, dict]:
    path = PERSIST / name
    if not path.is_dir():
        return False, f"missing persist dir {path}", {}
    skill_md = path / "SKILL.md"
    if not skill_md.is_file():
        return False, f"missing SKILL.md in {path}", {}
    text = skill_md.read_text(encoding="utf-8", errors="replace")
    parts = text.split("---", 2)
    if len(parts) < 3 or f"name: {name}" not in parts[1]:
        return False, "SKILL.md name does not match directory", {}
    anthropic_yaml = path / "agents" / "anthropic.yaml"
    if not anthropic_yaml.is_file():
        return False, "missing agents/anthropic.yaml", {}
    if not GATE.is_file():
        return False, f"missing package gate {GATE}", {}
    aai = subprocess.run(
        [sys.executable, str(GATE), "package", str(path)],
        text=True,
        capture_output=True,
        check=False,
    )
    evidence = {
        "host_save_path": str(path.resolve()),
        "aai_exit": aai.returncode,
        "anthropic_yaml": True,
    }
    if aai.returncode != 0:
        evidence["aai_out"] = (aai.stdout or aai.stderr or "").strip()
        return False, "validator failed", evidence
    return True, "persist path verified and package gate PASS", evidence


def main() -> int:
    requested = sys.argv[1] if len(sys.argv) > 1 else "status"
    target = sys.argv[2] if len(sys.argv) > 2 else "aai-cognitive-interface"
    req = requested.upper() if requested != "status" else "status"

    if req == "status":
        ok, reason, evidence = verify_skill(target)
        payload = {
            "requested": "status",
            "bound": ok,
            "host": "anthropic",
            "status": "BOUND-ANTHROPIC" if ok else "UNBOUND",
            "emitted_label": None,
            "checked_at": now(),
            "reason": reason,
            "claude_ai": "OBSERVED-FILE-LOAD" if ok else "NOT-OBSERVED",
            "claude_code": "OBSERVED-FILE-LOAD" if ok else "NOT-OBSERVED",
        }
        payload.update(evidence)
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0 if ok else 1

    if req in {"RUNTIME-SMOKE-PASS", "RUNTIME-VERIFIED", "ADVERSARIAL-PASS"}:
        return fail(req, "runtime and adversarial labels still require a separate live suite")

    if req != "INSTALLED":
        return fail(requested, f"unknown request {requested}")

    ok, reason, evidence = verify_skill(target)
    if not ok:
        return fail("INSTALLED", reason, evidence)

    payload = {
        "requested": "INSTALLED",
        "bound": True,
        "host": "anthropic",
        "status": "INSTALLED",
        "emitted_label": "INSTALLED",
        "scope": "anthropic-persist-only",
        "checked_at": now(),
        "reason": reason,
        "claude_ai": "PATH-VERIFIED",
        "claude_code": "PATH-VERIFIED",
    }
    payload.update(evidence)
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
