#!/usr/bin/env python3
"""
correct_timestamps.py

Applies a fixed-second delta to every HH:MM:SS timestamp in a document.
Built for the recurring correction type where a BWC export's overlay
timestamps run a fixed number of seconds off from verified ground truth
(for example: "all timestamps are 3 seconds too late, subtract 3 from
each").

This script does NOT verify the delta itself. Per
forensic-evidentiary-drafting's source grounding rules, the delta must
first be confirmed against at least one anchor point in the source
overlay or embedded timecode before running this script. The script
then applies that confirmed delta consistently, so no instance is
missed during manual editing.

Usage:
    python3 correct_timestamps.py INPUT.md --delta -3
    python3 correct_timestamps.py INPUT.md --delta -3 --apply -o OUTPUT.md
    python3 correct_timestamps.py INPUT.md --delta -3 --include-mmss

Default mode is dry-run: prints every match found and what it becomes,
for review before writing anything.

--apply writes the corrected file. Without -o, writes to
INPUT.corrected.md alongside the input.

--include-mmss also corrects bare M:SS or MM:SS tokens (relative video
position, not wall-clock time). Off by default because M:SS tokens are
ambiguous with other numeric pairs. Review the dry-run output carefully
before enabling this.
"""

import argparse
import re
import sys

HHMMSS = re.compile(r"(?<![\d:])(\d{1,2}):(\d{2}):(\d{2})(?![\d:])")
TIME_TOKEN = re.compile(
    r"(?<![\d:])(?:(?P<h>\d{1,2}):(?P<hm>\d{2}):(?P<hs>\d{2})|"
    r"(?P<m>\d{1,2}):(?P<ms>\d{2}))(?![\d:])"
)


def shift_hhmmss(match, delta):
    h, m, s = (int(g) for g in match.groups())
    if h > 23 or m > 59 or s > 59:
        raise ValueError(f"invalid HH:MM:SS token: {match.group(0)}")
    total = h * 3600 + m * 60 + s + delta
    total %= 24 * 3600
    if total < 0:
        total += 24 * 3600
    nh, rem = divmod(total, 3600)
    nm, ns = divmod(rem, 60)
    return f"{nh:02d}:{nm:02d}:{ns:02d}"


def shift_mmss(match, delta):
    m, s = (int(g) for g in match.groups())
    if s > 59:
        raise ValueError(f"invalid M:SS token: {match.group(0)}")
    total = m * 60 + s + delta
    if total < 0:
        total = 0
    nm, ns = divmod(total, 60)
    return f"{nm}:{ns:02d}"


def process(text, delta, include_mmss):
    changes = []

    def repl_hhmmss(m):
        old = m.group(0)
        new = shift_hhmmss(m, delta)
        changes.append((old, new))
        return new

    if not include_mmss:
        return HHMMSS.sub(repl_hhmmss, text), changes

    def repl_token(match):
        old = match.group(0)
        if match.group("h") is not None:
            h = int(match.group("h"))
            minute = int(match.group("hm"))
            second = int(match.group("hs"))
            if h > 23 or minute > 59 or second > 59:
                raise ValueError(f"invalid HH:MM:SS token: {old}")
            total = (h * 3600 + minute * 60 + second + delta) % (24 * 3600)
            nh, rem = divmod(total, 3600)
            nm, ns = divmod(rem, 60)
            new = f"{nh:02d}:{nm:02d}:{ns:02d}"
        else:
            minute = int(match.group("m"))
            second = int(match.group("ms"))
            if second > 59:
                raise ValueError(f"invalid M:SS token: {old}")
            total = max(0, minute * 60 + second + delta)
            nm, ns = divmod(total, 60)
            new = f"{nm}:{ns:02d}"
        changes.append((old, new))
        return new

    return TIME_TOKEN.sub(repl_token, text), changes


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                      formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("input", help="Input markdown or text file")
    parser.add_argument("--delta", type=int, required=True,
                         help="Seconds to add to each timestamp. Negative to subtract.")
    parser.add_argument("--apply", action="store_true",
                         help="Write the corrected file instead of dry-run")
    parser.add_argument("-o", "--output", help="Output path when --apply is used")
    parser.add_argument("--include-mmss", action="store_true",
                         help="Also correct bare M:SS / MM:SS tokens")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        text = f.read()

    try:
        out, changes = process(text, args.delta, args.include_mmss)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    if not changes:
        print("No matching timestamps found.", file=sys.stderr)
        sys.exit(1)

    if not args.apply:
        print(f"Dry run. Delta = {args.delta:+d}s. {len(changes)} timestamp(s) found.")
        print()
        for old, new in changes:
            print(f"  {old}  ->  {new}")
        print()
        print("Re-run with --apply to write the corrected file.")
        return

    output_path = args.output or (
        args.input.rsplit(".", 1)[0] + ".corrected." + args.input.rsplit(".", 1)[1]
        if "." in args.input else args.input + ".corrected"
    )
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(out)
    print(f"Wrote {output_path}. {len(changes)} timestamp(s) corrected by {args.delta:+d}s.")


if __name__ == "__main__":
    main()
