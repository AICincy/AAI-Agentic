---
name: forensic-evidentiary-drafting
description: Produces court-ready forensic analyses, declarations, suppression appendices, evidence inventories, and timeline reconstructions from source evidence. Use when the output analyzes or reconstructs source evidence for a legal proceeding. Triggers on forensic analysis, evidentiary report, BWC analysis, expert report, suppression memo, evidence inventory, or court timeline reconstruction.
---

# Forensic Evidentiary Drafting

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
subordinate domain module that supplies forensic evidentiary methods only. It
must not override, narrow, suspend, or reinterpret AAI. The user owns the
filing objective and material legal choices. Codex owns the in-scope
mechanics: source inspection, verification, extraction recovery, drafting,
validation, rendering, and routine matter-state updates.

Accept AAI's recovered objective, authorized scope, hard constraints,
authoritative sources and artifacts, next executable action, completion
evidence, and any human-only gate as the control state. AAI also governs
corrections, cognitive-ceiling takeover, artifact completion, and evidence or
status claims. Platform and safety instructions remain authoritative. Treat
corrections as hard constraints, repair every affected finding or derivative
document, and revalidate before delivery. During takeover, surface only one
actual gate or exact blocker.

The document and filing-readiness checks in this skill prove domain validation
only. They do not prove `SAVED`, `INSTALLED`, `RUNTIME-VERIFIED`, or
`ADVERSARIAL-PASS`. Complete the AAI artifact transaction for reusable
artifacts. Canonical directory: `forensic-evidentiary-drafting`. Hashed
folders are wrappers. See [references/package-identity.md](references/package-identity.md), [references/drafting-state.md](references/drafting-state.md),
[references/sibling-routing.md](references/sibling-routing.md), and [references/acceptance-tests.md](references/acceptance-tests.md). Filing is an AAI human gate.
`validate_document.py` is mechanical. Missing auditors keep drafts provisional.

Do not ask the user to supervise a routine retry, choose between equivalent
tools, or re-supply a source that an available in-scope retrieval or file
workflow can recover. Try a safe alternate route first. Surface only a
material unresolved gap or genuine decision gate.

For large independent source groups, parallelize extraction or verification
with subagents when useful. Give each branch a bounded source set and exact
deliverable. The primary agent owns reconciliation, legal synthesis, final
claim coverage, and filing-readiness verification.

## Codex/ChatGPT Work bindings

Use the installed `documents` skill for DOCX work and the installed `pdf`
skill for PDF creation/inspection when those formats are required. Invoke
`authority-currency-auditor`, `claim-source-auditor`, and
`aai-cognitive-interface` by skill name when their triggers apply. When this
skill needs a reference bundled in a sibling skill, resolve that installed
skill by its `SKILL.md` frontmatter name rather than assuming a fixed folder
path. For filing-related legal claims, re-check current authority on the web
before delivery.

## Purpose

This skill governs the structure, voice, and verification requirements for
any document derived from source evidence that a court will read. It fills
the gap between academic-style reports and court-ready filings.

## Matter context

IF a matter file (matter-[name]-verified-facts.md) exists for the active
case:
THEN load it before drafting. Treat verified facts as an accepted baseline
with their recorded provenance, and treat the exhibit ledger as the current
identifier state. Re-check the underlying source when provenance is absent,
the source identity/version changed, or the current draft conflicts with the
baseline. Assign new exhibit IDs without colliding with the ledger. Treat
logged user corrections as hard constraints.

IF no matter file exists:
THEN proceed using available context and sources. Create or update a matter
file from [references/matter-file-template.md](references/matter-file-template.md)
only when persistent matter state is within the requested objective.

## Document Types

| Type | Voice | Use when |
|---|---|---|
| Independent forensic analysis | Third-person neutral | Analyst presenting findings from source evidence to a court |
| Expert declaration/affidavit | First-person sworn | Analyst attesting to methodology and findings under penalty of perjury |
| Suppression memo appendix | Third-person neutral | Factual appendix to a defense motion, structured for attorney incorporation |
| Evidence inventory | Third-person neutral | Formal exhibit catalogue with source metadata and chain of custody |
| Timeline reconstruction | Third-person neutral | Chronological event table built from multiple source files with exhibit cross-references |

IF the user does not specify a document type:
THEN infer from context. Court hearing approaching with source evidence
available: forensic analysis. Attorney requests factual support: suppression
memo appendix. Multiple source files need organizing: evidence inventory.
State the inference and proceed.

## Trigger precedence with regulatory-complaint-drafting

IF the document's recipient is a court or clerk of courts:
THEN this skill's mandatory section order governs the document
structure. regulatory-complaint-drafting contributes recipient-authority
content (jurisdiction statement, relief scope) where applicable.

IF the document's recipient is an agency, regulatory body, or
institution rather than a court:
THEN regulatory-complaint-drafting's structure governs.
This skill contributes its evidence-grounding rules (finding-exhibit
anchoring, timestamp verification) where source evidence is involved.

IF the document is an Ohio pre-suit notice of intent:
THEN regulatory-complaint-drafting governs, and the notice stays
procedural per that skill's rule. If the tied case is in Hamilton County,
use this skill's Hamilton County reference for routing only when the notice
will actually be submitted through an identified court or clerk filing
channel. Apply only that channel's current confirmed rules.

## Mandatory Section Order

Every document whose structure this skill governs under the trigger-precedence
rules uses this section order. No sections may be omitted. Empty sections
state "Not applicable to this document." Current controlling court rules and
AAI hard constraints remain superior.

```
I.    Header block
II.   Introduction
III.  Jurisdiction and applicable standards
IV.   Forensic methodology
V.    Factual background
VI.   Findings
VII.  Exhibit list
VIII. Conclusion
IX.   Attestation
```

Load [references/section-templates.md](references/section-templates.md)
for the exact content requirements, table column specs, and attestation
language for each document type.

## Rules

### Structure rules

IF producing a document whose structure this skill governs under the
trigger-precedence rules:
THEN use the mandatory section order above. If a current controlling court
rule or AAI hard constraint requires a different structure, follow that
requirement, record the deviation, and validate against the controlling rule.

IF a finding is stated:
THEN it must cite at least one dated fact AND at least one supporting
exhibit. State supporting exhibits on a separate italic line immediately
below the finding narrative. Findings without exhibit anchors are rejected.

Exception: in a suppression memo appendix, follow the appendix template's
numbered-paragraph format. Put exhibit and timestamp citations inline and do
not add a separate italic supporting-exhibits line.

IF the factual background section contains three or more events:
THEN present as a table with columns: Timestamp/Date, Elapsed, Event,
Exhibit. Do not use prose narrative for chronological sequences.

IF the document contains exhibits:
THEN Section VII (Exhibit List) must contain a formal table with columns:
Exhibit letter/number, source locator (timestamp, page, Bates number),
source device or file, and evidentiary significance.

Exception: for an evidence-inventory document, Section VI is itself the
canonical inventory/exhibit table. Keep the Section VII heading for structural
stability and state that Section VI serves as the exhibit list. Do not
duplicate the same table merely to satisfy section numbering.

### Source grounding rules

IF a timestamp is cited from BWC, dashcam, surveillance, or any recorded media:
THEN it must be individually verified against the source overlay, metadata,
or embedded timecode. State the verification method. Unverified timestamps
are labeled "[UNVERIFIED]" in the output. Never carry forward a timestamp
from a prior document version without re-verification.

IF verification reveals that all timestamps in a source are off by a
fixed number of seconds (a constant delta):
THEN confirm the delta against at least one anchor point in the source
overlay first. Once confirmed, apply it consistently with
[scripts/correct_timestamps.py](scripts/correct_timestamps.py) rather
than editing each instance by hand. Run the script in dry-run mode
first, review every match, then apply. Log the confirmed delta and the
anchor point used in the matter file's correction log.

IF a quote is attributed to a specific person:
THEN it must be verified against audible audio or the original written
source. AI-generated transcripts are not ground truth. If the quote was
verified against audio, state "verified against audible BWC audio" or
equivalent. If verification was not possible, state "transcript-derived,
audio verification pending."

IF the source record contains a gap, cut, edit, or discontinuity:
THEN the gap must be documented as a finding. State the boundary
timestamps, the duration of the gap, and the evidentiary significance.
Do not interpolate events within the gap. Do not assume continuity
across a gap.

IF the analyst cannot determine a fact from available sources:
THEN state "This fact cannot be determined from available evidence" and
identify the specific missing source that would resolve it. Do not infer
to fill gaps. Do not present inference as established fact.

IF a source file is AI-generated (transcript, summary, OCR output):
THEN flag it in the methodology section with a reliability assessment.
State what the source was verified against (if anything) and what
passages are unreliable.

### Citation rules

IF a legal authority is cited:
THEN invoke authority-currency-auditor silently before delivery. All
citations must be verified as current. Cite: case name, reporter,
pinpoint page. Statute: title, section, subsection. Policy: department,
procedure number, section.

For filing, publication, external send, or any expressly current legal
deliverable, require fresh current-session authority verification. A prior
matter-file cache may guide retrieval, but it does not prove filing-day
currency.

IF authority-currency-auditor returns a status other than "current":
THEN flag the citation in the legal authorities table with the returned
status and correction note.

### Dependency invocation

IF this skill produces output:
THEN invoke these skills automatically before delivery (no user prompt
required):
  - authority-currency-auditor: on every legal citation
  - claim-source-auditor: on every factual assertion

IF the output spans multiple volumes or documents:
THEN invoke record-series-builder for consistent formatting across
the package.

### Document-type-specific rules

IF the document type is expert declaration/affidavit:
THEN use first-person voice throughout. Include a qualifications
paragraph after the header block. Use "I declare under penalty of
perjury under the laws of [jurisdiction] that the foregoing is true
and correct" as the attestation language.

IF the document type is suppression memo appendix:
THEN structure findings as numbered paragraphs (not headed subsections)
for attorney incorporation into a motion. Include "Respectfully
submitted" closing. Do not include legal argument; present only facts
and their evidentiary significance.

IF the document type is evidence inventory:
THEN include chain-of-custody fields: source, date received, format,
hash (if available), custodian. Each exhibit gets a unique identifier
that persists across all documents in the case. When source files are
available on disk, run
[scripts/hash_evidence.py](scripts/hash_evidence.py) to populate the
hash, format, size, and modified-time fields rather than leaving them
blank or computing them by hand.

IF the document type is timeline reconstruction:
THEN this document may also stand alone as a separate deliverable.
Include source cross-references for every entry. If multiple sources
cover the same event, note concordance or discrepancy.

### Topic-specific reference appendices

IF the matter involves a Terry stop predicated on recording police
activity, a First Amendment audit, or a related Section 1983 / Monell
claim in or near the Sixth Circuit:
THEN check
[references/sixth-circuit-first-amendment-recording.md](references/sixth-circuit-first-amendment-recording.md)
for framework citations before researching from scratch. Every citation
pulled from this appendix, including ones marked "verified for this
matter," still goes through authority-currency-auditor before delivery.

### Pro se filing rules

IF the filer is proceeding pro se (self-represented, not a licensed attorney):
THEN apply the following modifications to all document types:

  1. The attestation must not claim independent retention by counsel.
     Use the pro se attestation variant from section-templates.md.
     The attestation must reflect that the analyst and the filing party
     are the same individual.

  2. Do not use attorney-specific language ("counsel," "undersigned
     attorney," "trial attorney"). Use "the undersigned," "the filing
     party," or the party's name.

  3. The header block must include "Filing Status: Pro Se" as a row.

  4. Do not include an Ohio Bar ID or Supreme Court registration number.
     Pro se filers use their email address as the e-filing user ID.

IF the filer is pro se AND the document is a forensic analysis or
suppression memo appendix:
THEN acknowledge in the introduction that the analysis was conducted
by the filing party in a pro se capacity, not by a retained expert.
State provenance and methodology neutrally. Do not make a categorical claim
about evidentiary weight or admissibility merely from pro se status.

### Jurisdiction-specific filing rules

IF the target is any Hamilton County (Ohio) court or division, including
Common Pleas, Municipal Civil or Criminal, Domestic Relations, Probate,
Juvenile, or the First District Court of Appeals:
THEN first identify the exact court, division, and case type. Load the
Hamilton County reference for routing, then verify the current rules of that
specific court or division and every rule relied on against its official
source during the filing session. The Common Pleas General Division rulebook
does not govern another Hamilton County court or division by default. The
bundled reference is a workflow aid, not filing-day proof.

Load [references/hamilton-county-filing.md](references/hamilton-county-filing.md)
for the complete Hamilton County filing integration rules.

Candidate Hamilton County checks, applied only when current rules for the
identified court and division confirm them:

  1. For Common Pleas General Division under current Local Rule 34, output
     format is PDF for filing documents. Word (.doc/.docx) is used only
     for Proposed Entries or Proposed Orders. Do not produce docx when
     the clerk requires PDF.

  2. Apply the 20MB limit and split-cover procedure only when the current
     clerk rules for the identified filing channel confirm them.

  3. Verify the identified filing channel's current rejection and filing-date
     rules. Run the full validation checklist before delivery.

  4. In Common Pleas General Division, Rule 14(A) requires motions to be
     accompanied by a memorandum
     with "page and document references for all factual assertions."
     If this skill produces a suppression memo appendix, it must be
     paired with a Rule 14-compliant memorandum. The skill flags this
     as a required companion document.

  5. Municipal Civil filings require a Service Notification Form
     appended as the last page. Flag this as a post-production step
     when the target court is Municipal Civil.

  6. Pro se filers in Common Pleas "A" cases are exempt from the
     mandatory e-filing requirement (Local Rule 11(A), Local Rule
     34(A)(1)) but may still e-file voluntarily.

  7. Apply the current Ohio Rules of Superintendence privacy provisions.
     As of the July 1, 2026 restructuring, definitions are in Sup.R. 11.09
     and omission of personal identifiers is in Sup.R. 11.13. Re-verify the
     current numbering before filing.

  8. For Hamilton County Common Pleas General Division, current Local Rule 49
     governs AI-assisted court submissions. If AI assisted creation, editing,
     evidence analysis, or legal research for material submitted to the court,
     include the disclosure/certification the current rule requires. Verify
     the rule text and applicability fresh before submission.

IF the target court is NOT Hamilton County:
THEN omit the Hamilton County rules. Apply generic Ohio rules or the
rules of the identified jurisdiction instead.

## Template Spec (Guidance)

The following formatting guidance produces consistent, professional output.
These are defaults, not mandates. Deviate when the court or jurisdiction
requires a specific format.

| Element | Specification |
|---|---|
| Page size | US Letter (8.5 x 11 in, 12240 x 15840 DXA) |
| Margins | 1 inch all sides (1440 DXA) |
| Body font | Arial, 10pt (size: 20 in docx-js) |
| Heading 1 | Arial, 13pt bold, black, bottom border 1B3A5C, spacing before 360 after 160 |
| Heading 2 | Arial, 11pt bold, color 1B3A5C, spacing before 240 after 120 |
| Table header | Arial, 9pt bold white on #1B3A5C background |
| Table body | Arial, 9pt, alternating rows #F2F6FA and white |
| Table borders | 1pt solid #999999 |
| Cell padding | 60 top/bottom, 100 left/right (DXA) |
| Line spacing | 1.15 (line: 276 in docx-js) |
| Header | Document title (left), case short name (right), italic, 8pt, gray |
| Footer | Confidentiality notice (left), page number (center), date (right), 7pt, gray |
| Exhibit images | 420x236px centered, italic caption below in 8pt |
| Attestation | Signature line (underscore x30), title, date, preceded by 480 DXA spacing |
| Output format | Use the current rule for the identified court, division, recipient, case type, and document purpose. For Common Pleas General Division, apply verified Local Rule 34. |
| Max file size | Apply a limit and split procedure only when the identified current filing channel confirms them. |

## Voice

Third-person neutral for all document types except expert declarations.
Direct. No hedging. No speculative language except when quoting a source
that used speculative language (in which case, identify it as such).

Formatting follows aai-cognitive-interface: no em dashes or en dashes,
active voice, one idea per sentence. Legal voice additionally permits
colons and semicolons for clause separation within findings.

## Validation Checklist (Run Before Delivery)

IF the document is in final draft form and the environment provides code
execution:
THEN run [scripts/validate_document.py](scripts/validate_document.py) on
the draft first. The script mechanically checks: em/en dash presence,
mandatory section order, exhibit-list-to-findings cross-reference,
personal identifier patterns (SSN, full date of birth, account numbers),
attestation position, and timestamp consistency against a ground-truth
file when one is available. Any script failure is a blocking defect: fix
it before walking the checklist below. The script supplements the
checklist; it does not replace any item.

IF code execution is unavailable:
THEN state that the mechanical pass was not run and walk the full
checklist manually.

Before presenting the final document, confirm:

1. Every finding cites at least one dated fact and one supporting exhibit.
2. Every timestamp has been verified against source metadata (not carried
   from prior drafts).
3. Every legal citation has been verified as current by authority-currency-auditor.
4. Every factual assertion has been grounded by claim-source-auditor.
5. The exhibit list table matches the exhibits referenced in findings.
6. Dates, names, badge numbers, and case identifiers are consistent
   throughout the document.
7. No em dashes or en dashes appear anywhere in the output.
8. The attestation appears at the end, not the beginning.
9. The section order matches the mandatory order above.
10. AI-generated source materials are flagged with reliability assessments.
11. If Hamilton County: exact court/division and case type are identified,
    and output format matches that court's current requirements. For Common
    Pleas General Division, apply the verified Local Rule 34 format rule.
12. If the identified Hamilton County filing channel currently imposes a
    20MB limit: the document is under it or a compliant split plan exists.
13. If a Common Pleas General Division suppression memo appendix: companion
    Rule 14(A) memorandum is identified or flagged as required.
14. If Municipal Civil: Service Notification Form requirement is flagged
    as a post-production step.
15. If pro se: attestation uses the pro se variant. No attorney-specific
    language appears in the document.
16. Personal identifiers (SSN, full DOB, account numbers) are omitted or
    redacted under the current Ohio filing-privacy rules. Re-verify the
    operative Sup.R. numbering before filing.
17. If Hamilton County Common Pleas General Division: current Local Rule 49
    has been checked for AI-assisted material, and any required attached
    disclosure/certification is included in the filing package.

## References

- [references/section-templates.md](references/section-templates.md):
  Exact section header language, table column specs, attestation language,
  and content requirements for each of the five document types. Includes
  pro se attestation variants.

- [references/hamilton-county-filing.md](references/hamilton-county-filing.md):
  Hamilton County-specific filing format requirements, service procedures,
  Local Rule 14 memorandum requirements, and e-filing procedures derived
  from the Hamilton County Local Rules of Court and Clerk of Courts
  e-filing documentation.

- [references/matter-file-template.md](references/matter-file-template.md):
  Shared verified-facts ledger template used across this skill,
  regulatory-complaint-drafting, record-series-builder,
  claim-source-auditor, and research-execution-briefs.

- [references/sixth-circuit-first-amendment-recording.md](references/sixth-circuit-first-amendment-recording.md):
  Doctrinal framework and candidate citations for Terry stop, First
  Amendment recording, and Monell claims. All citations still require
  authority-currency-auditor before delivery.

- [scripts/hash_evidence.py](scripts/hash_evidence.py): Computes SHA-256,
  format, size, and modified-time for evidence files, formatted for the
  evidence inventory chain-of-custody table.

- [scripts/correct_timestamps.py](scripts/correct_timestamps.py): Applies
  a confirmed fixed-second delta to every HH:MM:SS timestamp in a
  document. Dry-run by default.

- [scripts/validate_document.py](scripts/validate_document.py): Mechanical
  pre-delivery validation gate. Checks dash presence, section order,
  exhibit cross-references, personal identifier patterns, attestation
  position, and timestamp consistency. Report-only; exits nonzero on any
  failure; never mutates this document.

When filesystem execution is available, run
`python3 scripts/aai_runtime_gate.py package <skill-directory>` after
modifying this skill. That is STATIC-PASS only.
