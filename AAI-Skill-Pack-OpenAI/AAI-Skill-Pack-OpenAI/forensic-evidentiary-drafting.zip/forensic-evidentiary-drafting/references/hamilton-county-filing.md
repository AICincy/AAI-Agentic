# Quarantined cache

This file is not current local rule.

The August 8, 2026 Hamilton County snapshot was moved to
`aai-family-0.2.0/untrusted-cache/hamilton-county-filing.md`.

Before any filing instruction, run
`aai-cognitive-interface/family/scripts/refetch_untrusted_cache.py filing`
and re-fetch the clerk site and current local rules. If the fetch fails,
stop at DECISION-GATED.
