# Package Identity

| Field | Value |
| --- | --- |
| Skill name | forensic-evidentiary-drafting |
| Directory name | forensic-evidentiary-drafting |
| Role | Subordinate domain module |
| Governor | aai-cognitive-interface |
| Implemented surface | Section order, matter file, hash/timestamp helpers, validate_document.py |
| Not implemented | Filing, service, typed record graphs, current local-rule attestation |

A hashed export folder such as `skill-<id>/` is a transport wrapper.

Claim STATIC-PASS only after `python3 scripts/aai_runtime_gate.py package <this-directory>` returns PASS in `package-skill` mode.

`validate_document.py` exit 0 is a mechanical domain check. It is not SAVED, INSTALLED, filing-ready transmission, or runtime verification.
