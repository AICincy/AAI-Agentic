# Sibling Routing

AAI stays in force. This skill preserves provenance while drafting.

| Module | When to load | If missing |
| --- | --- | --- |
| aai-cognitive-interface | Every turn | Say the governor is absent. Filing stays a human gate. |
| claim-source-auditor | Every record-backed fact | Keep statements as observations. Do not promote to findings. |
| authority-currency-auditor | Every citation and local rule | Label UNVERIFIED. Do not call the draft filing-ready. |
| regulatory-complaint-drafting | Agency recipient rather than court | That skill's structure governs. |
| record-series-builder | Multi-volume packet | Deliver the single draft; skip series packaging. |
| documents / pdf | Rendered court copies | Deliver Markdown. Do not claim DOCX/PDF exist. |
| personal-context | Prior matter file | Structured retrieval gate. Do not reconstruct. |

Hamilton County rows in hamilton-county-filing.md were last source-checked 2026-08-08. Re-check the official local-rules book before any filing-ready claim.
