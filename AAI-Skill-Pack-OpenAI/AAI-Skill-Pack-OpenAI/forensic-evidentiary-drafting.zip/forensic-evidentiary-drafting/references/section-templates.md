# Section Templates by Document Type

## Table of Contents

1. Independent Forensic Analysis
2. Expert Declaration/Affidavit
3. Suppression Memo Appendix
4. Evidence Inventory
5. Timeline Reconstruction
6. Pro Se Attestation Variants
7. Cross-Document Consistency Rules

---

## 1. Independent Forensic Analysis

### I. Header Block

Table format, two columns (label, value). Required rows:

| Row | Content |
|---|---|
| Submitted by | Analyst name or "Independent Forensic Analyst (signature block below)" |
| Date | Filing date |
| Case | Case name (party v. party) |
| Court | Court name, jurisdiction |
| Charge | Statute, offense name, degree |
| Next hearing | Date |
| Respondent/Defendant | Name, age, location |
| Officers/Respondents | Names, badge numbers, roles |
| Incident | Date, time, timezone, address |
| Filing status | Pro Se or Represented by Counsel (include only if pro se) |

### II. Introduction

Two to three sentences. State: (1) what evidence was analyzed, (2) how many
findings the analysis identifies, (3) the purpose (e.g., "for the
consideration of the court in advance of the [date] hearing").

IF the filer is pro se:
THEN add one sentence: "This analysis was conducted by [name] in a pro se
capacity pursuant to [state] law."

### III. Jurisdiction and Applicable Standards

Table format, three columns:

| Authority | Status | Standard |
|---|---|---|
| Full case cite or statute | Current/Amended/etc. | One-sentence statement of the applicable legal standard |

Include only authorities actually applied in the findings. Do not pad with
tangential citations.

### IV. Forensic Methodology

Three paragraphs:
1. Source file specifications (format, resolution, duration, device).
2. Extraction methodology (tools, intervals, encoding, quality).
3. Verification protocol (how timestamps were confirmed, statement that
   frames are unaltered).

### V. Factual Background

Table format, four columns:

| Timestamp/Date | Elapsed | Event | Exhibit |
|---|---|---|---|
| Source-verified timestamp | Time since first event | Factual description, no legal conclusions | Exhibit letter/number |

Narrative paragraph below the table stating the key temporal relationships
(e.g., elapsed time between seizure and witness statement).

### VI. Findings

Each finding follows this structure:

```
Finding [N]: [Title as a declarative statement of the finding]
  [Heading 2]

[Narrative paragraph(s) stating the finding, tying it to specific
timestamps and exhibits, applying the relevant legal standard.]

Supporting exhibits: [List of exhibit letters with brief descriptions].
  [Italic, 9pt]
```

Findings must be ordered by evidentiary significance (most important first)
or chronologically. State the ordering principle in the introduction.

### VII. Exhibit List

Table format, four columns:

| Exhibit | Source Locator | Source Device/File | Evidentiary Significance |
|---|---|---|---|
| Letter/number | Timestamp, page, Bates | Device ID, filename | One sentence stating why this exhibit matters |

Follow the table with embedded exhibit images (if applicable), each with
a centered italic caption stating exhibit letter, timestamp, and one-line
description.

### VIII. Conclusion

Numbered list of evidentiary concerns (not legal arguments). Each item
states a fact-based concern derived from the findings. Final paragraph
identifies dispositive missing evidence.

### IX. Attestation

Standard (retained analyst) version:
```
I affirm that the findings in this analysis are based on the sources and
methodology identified in this document. My role in preparing this analysis
is [state role or relationship accurately]. [State compensation or conflict
information only if known and relevant.]

All [timestamps/measurements/extractions] were verified against [source].
The methodology employed is replicable.

[480 DXA spacing]
_______________________________
[Title]
Date: [Date]
```

Pro se version: See Section 6 below.

---

## 2. Expert Declaration/Affidavit

Same section order as forensic analysis with these modifications:

### I. Header Block
Add row: "Declarant" with full legal name.

### After Header Block, Before II
Insert "Qualifications" section:
```
I, [full name], declare as follows:

1. I am [title/role]. I have [X years] of experience in [field].
2. I have been retained as [role] in this matter.
3. My qualifications include [credentials, certifications, prior
   court appearances as expert].
4. I have reviewed the following materials: [list].
```

### IX. Attestation (replaces standard attestation)
```
I declare under penalty of perjury under the laws of [jurisdiction]
that the foregoing is true and correct.

Executed on [date] at [city, state].

_______________________________
[Full legal name]
[Title/credentials]
```

---

## 3. Suppression Memo Appendix

Same section order with these modifications:

### II. Introduction
State: "This factual appendix is submitted in support of Defendant's
Motion to Suppress. The appendix presents [N] factual findings derived
from [source evidence type]."

IF the filer is pro se:
THEN state: "This factual appendix is submitted by [name], proceeding
pro se, in support of Defendant's Motion to Suppress. The appendix
presents [N] factual findings derived from [source evidence type]."

### Filing integration note (Hamilton County)

IF the target court is Hamilton County Common Pleas General Division and
current Local Rule 14(A) applies:
THEN this appendix must be accompanied by a memorandum in support of
the motion per Local Rule 14(A). The memorandum must include:
  - A brief statement of the grounds for the motion
  - Citations of authorities relied upon
  - Page and document references for all factual assertions
  - Proof of service per Civil Rule 5

The appendix itself does not satisfy Rule 14(A). The motion and
memorandum are separate filings. Flag this as a required companion
document in the delivery notes.

### VI. Findings
Use numbered paragraphs instead of headed subsections:
```
1. [Finding statement with exhibit and timestamp citations.]
2. [Finding statement with exhibit and timestamp citations.]
```
No finding titles. No italic "supporting exhibits" line (citations are
inline). This format allows attorneys (or the pro se filer) to
incorporate paragraphs by reference in the motion body.

### VIII. Conclusion
Replace with: "Respectfully submitted for the consideration of the Court."
No numbered concerns. The motion body handles legal argument.

### IX. Attestation
Use the standard attestation or the pro se variant (Section 6) as
appropriate.

---

## 4. Evidence Inventory

### I. Header Block
Same as forensic analysis.

### II. Introduction
State total exhibit count, source file count, and time span covered.

### III-IV
May be abbreviated or marked "See accompanying forensic analysis."

### V. Factual Background
Retain the heading and state: "Not applicable to this document. The inventory
in Section VI is the factual record."

### VI. Replace with "Inventory"
Table format, seven columns:

| Ex. | Description | Source File | Format | Date Received | Custodian | Hash (if available) |
|---|---|---|---|---|---|---|

### VII. Exhibit List
Retain the heading and state: "Not applicable to this document. The inventory
table in Section VI serves as the exhibit list."

### VIII. Conclusion
State completeness: "This inventory covers [N] of [M] known exhibits.
The following items have not been produced: [list]."

### IX. Attestation
Standard attestation or pro se variant (Section 6) with addition:
"The inventory accurately reflects all evidence in my custody as of [date]."

---

## 5. Timeline Reconstruction

### I. Header Block
Same as forensic analysis.

### II. Introduction
State: time span covered, number of source files consulted, number of
events documented.

### III-IV
May be abbreviated or marked "See accompanying forensic analysis."

### V. Replace with "Reconstructed Timeline"
Table format, five columns:

| Timestamp/Date | Source | Event | Concordance | Exhibit |
|---|---|---|---|---|
| Verified timestamp | File/device that produced this entry | Event description | Confirmed by N sources / Single source only / Conflict (see note) | Exhibit letter |

If multiple sources cover the same event, the Concordance column states
whether they agree. If they conflict, add a "Discrepancy Note" paragraph
below the table entry.

### VI. Findings
Retain the heading. Include findings if the timeline reveals matters not
apparent from individual source review, such as temporal gaps,
contradictions between sources, or events that could not have occurred in
the stated sequence. Otherwise state: "Not applicable to this document."

### VII-IX
Same as forensic analysis.

---

## 6. Pro Se Attestation Variants

These variants replace the standard attestation when the filer is
proceeding pro se. The key difference: a pro se filer is both the
analyst and the filing party, so the attestation cannot claim
independent retention by counsel or absence of relationship to the
parties.

### Pro Se Forensic Analysis Attestation
```
I, [full name], am the [Defendant/Plaintiff] in this matter and am
proceeding pro se. I conducted this analysis personally using the
methodology described in Section IV. My relevant qualifications or training,
if any, are stated accurately in this document. I present these findings as a
party to this case, not as a retained expert.

The findings presented herein are based solely on [list source
categories]. All [timestamps/measurements/extractions] were verified
against [source]. The methodology employed is described in sufficient
detail to be replicable.

I affirm that the factual statements in this document are true and
accurate to the best of my knowledge and ability.

[480 DXA spacing]
_______________________________
[Full legal name], Pro Se
Date: [Date]
```

### Pro Se Suppression Memo Appendix Attestation
```
Respectfully submitted,

[480 DXA spacing]
_______________________________
[Full legal name], Pro Se
[Address]
[Phone]
[Email]
Date: [Date]
```

### Pro Se Evidence Inventory Attestation
```
I, [full name], am the [Defendant/Plaintiff] in this matter and am
proceeding pro se. The inventory accurately reflects all evidence in
my custody as of [date].

I affirm that the descriptions and metadata recorded in this inventory
are true and accurate to the best of my knowledge and ability.

[480 DXA spacing]
_______________________________
[Full legal name], Pro Se
Date: [Date]
```

### Pro Se Timeline Reconstruction Attestation
```
I, [full name], am the [Defendant/Plaintiff] in this matter and am
proceeding pro se. This timeline was reconstructed from the sources
identified in the Concordance column and verified using the methodology
described in Section IV.

I affirm that the events, timestamps, and source attributions in this
document are true and accurate to the best of my knowledge and ability.

[480 DXA spacing]
_______________________________
[Full legal name], Pro Se
Date: [Date]
```

### Selection logic

IF the filer is pro se:
THEN use the corresponding pro se variant from this section.

IF the filer is pro se AND the document type is expert declaration/affidavit:
THEN do not label the filer a retained or independent expert merely because
the document is sworn. Determine what the requested filing actually needs and
what the governing jurisdiction permits. When an expert-status representation
would be unsupported, use a party declaration or forensic analysis with
accurate provenance instead. Verify any admissibility or qualification issue
against current law before making a categorical statement.

---

## 7. Cross-Document Consistency Rules

IF multiple documents are produced for the same case:
THEN exhibit identifiers (letters/numbers) must be consistent across all
documents. Exhibit A in the forensic analysis is Exhibit A in the timeline
reconstruction, the evidence inventory, and the suppression memo appendix.

IF a finding in one document relies on a finding in another:
THEN cite it: "See Forensic Analysis, Finding 3."

IF timestamps differ between documents for the same event:
THEN this is an error. Resolve before delivery.

IF multiple documents are filed in Hamilton County:
THEN identify the exact court, division, case type, document purpose, and
filing channel. Apply a 20MB limit, split-cover procedure, or separate-filing
rule only when that identified channel's current official rules confirm it.
Do not import Common Pleas General Division defaults into Domestic Relations,
Municipal Court, or the First District Court of Appeals.
