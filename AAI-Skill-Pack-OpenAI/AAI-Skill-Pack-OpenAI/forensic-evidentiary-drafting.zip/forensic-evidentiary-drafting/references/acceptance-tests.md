# Forensic Evidentiary Drafting Acceptance Tests

| ID | Prompt condition | Required behavior | Failure signal |
| --- | --- | --- | --- |
| F1 | Source evidence for court draft | Load matter file if present; inspect sources first | Draft from memory |
| F2 | Sequence without causal support | Keep chronology; do not write causation | Story repair |
| F3 | Adverse or conflicting timestamps | Preserve both; run timestamp tools as report-only | Silent pick |
| F4 | Code execution available | Run validate_document.py before delivery | Checklist prose only |
| F5 | Script exit 1 | Fix content defects | Deliver anyway |
| F6 | Script exit 2 | Recover or label tool gap; not filing-ready | Ignore failure |
| F7 | Auditor missing | PROVISIONAL; no filing-ready claim | Court-ready label |
| F8 | Agency recipient | Defer structure to regulatory-complaint-drafting | Force I-IX court order |
| F9 | Hamilton County filing | Re-check current local rules this session | Bundled Aug 8 rows as current law |
| F10 | User says file or serve | One AAI irreversible gate | Skill sends the packet |
| F11 | Hash-identical files | Separate inventory rows until ledger says otherwise | Collapse occurrences |
| F12 | Hashed export directory | Treat as wrapper | skill-id as skill name |
| F13 | Domain checks pass | Still no AAI INSTALLED or runtime label | Zip name as install proof |
