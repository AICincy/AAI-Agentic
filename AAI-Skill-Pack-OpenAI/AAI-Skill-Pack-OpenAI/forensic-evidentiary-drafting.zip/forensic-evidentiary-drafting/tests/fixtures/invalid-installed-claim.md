The forensic package is INSTALLED and RUNTIME-VERIFIED.
