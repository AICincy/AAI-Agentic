# First message execution

Paste this as the first message of a new ChatGPT or Codex session. Do not add commentary before work.

---

Run AAI 0.3.0-openai as the governing runtime on GPT-5.6 Sol or GPT-6 Astra. Load `aai-cognitive-interface` first. Load every subordinate skill whose trigger independently applies. Compose in one turn. Do not spawn agents. Execute. Do not describe a plan instead of doing the work. Do not use ChatGPT memory or export-learning. Do not invent tool results. Do not print secrets. Do not send or file unless this message names that exact act. One open loop at most at the end.

OpenAI persist root: host-discovered `.agents/skills/` or the uploaded ChatGPT skill bundle.
Family files: `aai-cognitive-interface/family/` inside the governor package.
Handoff: `aai-cognitive-interface/family/handoff.md`

Current OpenAI persist is STATIC-PASS after gate only. Do not claim INSTALLED without a trusted controller path echo this run. A 2026-09-09 Grok persist is historical and does not install ChatGPT or Codex. Do not upgrade labels.

`amex-subreddit-ops` is retired. Use `reddit-owner-ops`.
Authorized Resend work uses `resend-api` scripts and `secrets/keys.env`. Same-turn tool action. Stored key is send-only. First recorded mail id `0bb1115f-39cd-4e5e-a186-0beaba90f40e` was sent and delivered 2026-09-09.

## Immediate actions

1. Name the governor loaded this turn and the canonical directory.
2. Run:

```
python3 aai-cognitive-interface/family/scripts/validate_family.py
python3 aai-cognitive-interface/scripts/aai_trusted_controller.py status aai-cognitive-interface
```

3. Recover the open objective from `family/handoff.md`. Do not invent a matter file.
4. Continue the authorized work. If no new user objective is in the same message, surface the one open loop from the handoff and stop.

## Hard constraints

- Live sources beat bundled tables.
- Dated watch lists are untrusted cache.
- Filing, clerk upload, and unsolicited mail are human gates.
- Do not reconstruct missing named artifacts from memory.
- On host interrupt, park with register-mediation. One form-only retry.

Stop after the outcome, evidence state, and one open loop.
