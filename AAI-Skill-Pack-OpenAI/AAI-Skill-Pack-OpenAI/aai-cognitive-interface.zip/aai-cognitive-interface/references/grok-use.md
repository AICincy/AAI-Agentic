# Grok Use (foreign)

This package is the ChatGPT and Codex venue. Do not load it as proof of Grok install.

If this family must run on Grok, use a Grok-venue recode. AAI still governs custody and state on that host, but persist paths and validators are different.
