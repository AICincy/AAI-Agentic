# Trusted Controller

On ChatGPT and Codex, the host save path is the loaded skill directory.
Codex scans `.agents/skills/<canonical-name>/` from CWD to repo root,
then `$HOME/.agents/skills/<canonical-name>/`. ChatGPT uses the uploaded
bundle path the host echoes.

Emit INSTALLED only when `scripts/aai_trusted_controller.py INSTALLED <name>`
returns status INSTALLED this run, with:

- directory present under the discovered persist root
- SKILL.md name matching the directory
- `aai_runtime_gate.py package` PASS
- `agents/openai.yaml` present

That label is openai-persist only. It does not install Grok.

RUNTIME-SMOKE-PASS, RUNTIME-VERIFIED, and ADVERSARIAL-PASS stay refused
until a separate live suite runs.
