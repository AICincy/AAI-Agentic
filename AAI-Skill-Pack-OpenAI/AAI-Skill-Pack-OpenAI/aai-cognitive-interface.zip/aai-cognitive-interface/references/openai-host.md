# OpenAI Host Binding

This family runs on ChatGPT, Codex, API, and Atlas. Grok is a foreign host.

Target models: GPT-5.6 Sol and GPT-6 Astra.

## What this host exposes

| Capability | This workspace |
| --- | --- |
| Skill persist path | Codex: `.agents/skills/<name>/` from CWD to repo root, then `$HOME/.agents/skills/<name>/`. ChatGPT: uploaded skill bundle. |
| Skill format | OpenAI ChatGPT skill format. `SKILL.md` plus `agents/openai.yaml`. |
| Files | Host file tools, Codex workspace, ChatGPT Files |
| Web | Host web, browse, and connected search tools actually exposed this turn |
| Connected | Discover the current turn. Recorded inventory is not this turn's list. |
| Chat history search | Use when the host exposes it. Otherwise Personal Context degrades. |
| ChatGPT memory / export-learning | NOT A SOURCE |
| Grok persist path | FOREIGN. Do not claim a Grok install from this package. |

Discover the current turn's tools before use. Inventory files are not this turn's tool list.

## Status on OpenAI

| Label | Evidence required |
| --- | --- |
| DRAFTED | Content exists |
| STATIC-PASS | `python3 scripts/aai_runtime_gate.py package <dir>` returns PASS |
| OPENAI-PRESENT | Skill directory exists at a Codex-scanned or ChatGPT-uploaded path and the package gate prints PASS |
| SAVED | Durable write returned a path in this run |
| INSTALLED | Refused unless a trusted live controller plus host-echoed save path exist |
| RUNTIME-* | Refused without live controller |

OPENAI-PRESENT is not INSTALLED. It is path-plus-format evidence on this host.

## Load rule

Load `aai-cognitive-interface` first on every ChatGPT or Codex turn that uses this family. Domain skills supply methods only.

## Product prompt layers

ChatGPT custom instructions, memory, and Codex `AGENTS.md` are product prompt layers. They are not the skill persist path.

Custody and method live in the loaded skill bundle. Do not paste AAI, domain skill bodies, matter facts, or tool inventories into a memory or custom-instruction box. Do not treat a named custom GPT as proof that AAI loaded.

Krass's explicit user instructions take precedence over skill style. They do not waive AAI custody, human-only gates, status honesty, or runtime-only source rules.

## Adaptation vs memory

Do not use ChatGPT memory, model weights, or an export dump as the world model. Adapt per `adaptation.md`.
