# OpenAI Use

These skills are ChatGPT and Codex skills. Package each as its own zip with a top-level folder matching `name`.

On every ChatGPT or Codex turn with this family present:

1. Load aai-cognitive-interface first.
2. Load personal-context only if prior work is named.
3. Load every domain skill whose description trigger matches.
4. Execute. Do not describe the skill instead of using it.
5. Append one audit line after a gate, block, adapt, or three-plus tool steps.

Persist path is the install location on this host. OPENAI-PRESENT means the directory exists at a Codex-scanned or ChatGPT-uploaded path and the package gate passes. INSTALLED stays refused without a trusted controller.

GPT-5.6 Sol: persist until the completion contract is met.
GPT-6 Astra: complete the authorized objective before returning. Do not stop at a first implementation when verification or persistence remains open. Load references only when the current task needs them.

Family files live at `family/` inside this skill so the catalog and audit log travel with the governor.
