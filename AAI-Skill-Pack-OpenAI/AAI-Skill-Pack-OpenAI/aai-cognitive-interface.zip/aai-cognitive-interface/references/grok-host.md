# Grok Host Binding (foreign)

This OpenAI venue pack does not govern Grok. Grok is a foreign host.

Do not claim a Grok persist path, GROK-PRESENT, or Grok INSTALLED from this package.
If a later Grok recode is required, restore a Grok-specific host binding. Do not mix venues.
