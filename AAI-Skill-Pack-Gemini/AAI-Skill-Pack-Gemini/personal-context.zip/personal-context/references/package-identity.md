# Package Identity

| Field | Value |
| --- | --- |
| Skill name | personal-context |
| Directory name | personal-context |
| Role | Subordinate host-bridge |
| Governor | aai-cognitive-interface |

This package supplies retrieval gates. It cannot search Gemini or Gemini CLI
history unless the current host exposes that tool.
