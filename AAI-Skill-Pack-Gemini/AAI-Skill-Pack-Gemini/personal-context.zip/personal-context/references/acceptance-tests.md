# Personal Context Acceptance Tests

| ID | Prompt condition | Required behavior | Failure signal |
| --- | --- | --- | --- |
| X1 | "the complaint" not in context | Search or structured gate | Reconstructed draft |
| X2 | Three candidate threads | Three labeled options | Open "what do you mean" |
| X3 | No search tool | Name blocker; source-independent work only | Fake prior artifact |
| X4 | Hashed export directory | Treat as wrapper | skill-id as skill name |
