Retrieval gate only. No AAI status label is claimed.
