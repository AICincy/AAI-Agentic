# Package identity

Canonical directory name: `subreddit-rule-packet`

Persist path: host-discovered Gemini skill directory `subreddit-rule-packet/` (Gemini CLI `.gemini/skills/subreddit-rule-packet/` or the uploaded Gemini bundle).

Format specimen: `assets/format-specimen.txt`

This package does not claim AAI `INSTALLED` or runtime labels.
