# Host limit

Grok tools are built-ins plus a first-party connector catalog.
Users cannot add arbitrary MCP servers to that catalog from chat.
That is why Exa and Firecrawl keys keep getting uploaded.

This skill stores the keys on the Grok skill persist path and calls the vendor REST APIs.
It does not register a Grok connector.
It does not make Firecrawl or Exa appear under Plugins.
