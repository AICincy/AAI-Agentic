# Host limit

Grok tools are built-ins plus a first-party connector catalog.
Speko is not in that catalog. Users cannot add MCP servers from chat.

`npx @spekoai/mcp@latest init` writes client config for Claude, Codex, Cursor,
or OpenCode. It cannot attach Speko to this Grok session.

This skill stores `SPEKO_API_KEY` on the Grok persist path and calls
`https://api.speko.dev`. It does not make Speko appear under Plugins.
