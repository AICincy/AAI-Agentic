---
name: speko-mcp
description: Operates Speko voice agents from this Grok host via REST because Grok has no Speko MCP plugin slot. Use when Krass says Speko, Speko MCP, voice agent, AAI-Krass voice, @spekoai/client, agents.create, test session, or npx @spekoai/mcp. AAI subordinate. Never print or commit the live key. Re-fetch live Speko docs.
---

# Speko MCP

`aai-cognitive-interface` is the governing runtime. This skill is a subordinate
Speko control-plane route. It must not override AAI. Platform safety rules stay
authoritative.

Grok cannot attach `https://mcp.speko.ai/mcp` as a plugin. Use REST against
`https://api.speko.dev` with `SPEKO_API_KEY`. Use the public docs MCP at
`https://speko.ai/.well-known/mcp` for unauthenticated `docs.search`.

Canonical directory: `speko-mcp`.

## Secrets

Read `/home/workdir/.grok/skills/speko-mcp/secrets/keys.env`.
Never print the file. Never echo keys. Never put keys in SKILL.md, chat, GitHub, or artifacts.

If the file is missing or `SPEKO_API_KEY` is empty, say
`BLOCKED secrets/keys.env missing` and stop. Do not invent a key.

Load

```bash
set -a
# shellcheck disable=SC1091
source /home/workdir/.grok/skills/speko-mcp/secrets/keys.env
set +a
```

## Endpoints

| Surface | URL | Auth |
| --- | --- | --- |
| Docs MCP | `https://speko.ai/.well-known/mcp` | none |
| Operational MCP | `https://mcp.speko.ai/mcp` | OAuth or `sk_live_` |
| Platform API | `https://api.speko.dev` | Bearer key |
| Router | `https://router.speko.dev` | Bearer key |
| Keys UI | `https://platform.speko.ai/agents/keys` | human |

Re-fetch docs before changing request shapes. Do not treat this file as the API spec.

## Execute

Docs search

```bash
python3 /home/workdir/.grok/skills/speko-mcp/scripts/docs_search.py "QUERY"
```

Account write or read

```bash
python3 /home/workdir/.grok/skills/speko-mcp/scripts/speko_call.py METHOD PATH [JSON]
```

Examples

```bash
python3 /home/workdir/.grok/skills/speko-mcp/scripts/speko_call.py GET /v1/agents
python3 /home/workdir/.grok/skills/speko-mcp/scripts/speko_call.py POST /v1/agents "$(cat /home/workdir/artifacts/aai-krass-voice/agent.json)"
python3 /home/workdir/.grok/skills/speko-mcp/scripts/speko_call.py POST /v1/sessions '{"mode":"cascade","agentId":"AGENT_ID","ttlSeconds":900}'
```

Every mutating POST must send a fresh `Idempotency-Key`. The script does that.

## Voice agent contract for AAI-Krass

Language `en-US`. Objective `latency`.

Recommended English cascade allowlist from current Speko agent docs

- STT `deepgram:nova-3` with `assemblyai` failover
- LLM `openai:gpt-5` with `anthropic` failover
- TTS `cartesia` with `elevenlabs:eleven_flash_v2_5` failover
- Turn profile `conversational`, interruption `adaptive`

Persist the agent. Mint sessions on the server. Browser receives only
`transportToken` and `transportUrl`. Never send `SPEKO_API_KEY` to the client.

Author `firstMessage` in English. Do not rely on runtime translation.

Live create, deploy, test-call, and phone dial are human-gated only if they
place a call or spend credits without prior authorization. This request already
authorized create, deploy, and a test session.

## Host limit

`npx @spekoai/mcp@latest init` is an interactive OAuth installer for Claude,
Codex, Cursor, and similar clients. It does not register a Grok plugin.

See [references/host-limit.md](references/host-limit.md) and
[references/best-practices.md](references/best-practices.md).

## Status

Do not claim INSTALLED or a live Speko agent id unless `speko_call.py` returned
that id this run. A scaffolded JSON file is DRAFTED or SAVED only.
