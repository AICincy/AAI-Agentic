#!/usr/bin/env bash
set -euo pipefail
# shellcheck disable=SC1091
source /home/workdir/.grok/skills/resend-api/scripts/load_key.sh

export RESEND_FROM="${RESEND_FROM:-onboarding@resend.dev}"
export RESEND_TO="${RESEND_TO:-jaredcincy@gmail.com}"
export RESEND_SUBJECT="${RESEND_SUBJECT:-Hello World}"
export RESEND_HTML="${RESEND_HTML:-<p>Congrats on sending your <strong>first email</strong>!</p>}"

BODY="$(python3 - <<'PY'
import json, os
print(json.dumps({
    "from": os.environ["RESEND_FROM"],
    "to": os.environ["RESEND_TO"],
    "subject": os.environ["RESEND_SUBJECT"],
    "html": os.environ["RESEND_HTML"],
}))
PY
)"

curl -sS -X POST 'https://api.resend.com/emails' \
  -H "Authorization: Bearer ${RESEND_API_KEY}" \
  -H 'Content-Type: application/json' \
  -d "$BODY"
echo
