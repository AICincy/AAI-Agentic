#!/usr/bin/env bash
set -euo pipefail
# shellcheck disable=SC1091
source /home/workdir/.grok/skills/resend-api/scripts/load_key.sh
EMAIL_ID="${1:?usage: get_email.sh <email_id>}"
curl -sS "https://api.resend.com/emails/${EMAIL_ID}" \
  -H "Authorization: Bearer ${RESEND_API_KEY}"
echo
