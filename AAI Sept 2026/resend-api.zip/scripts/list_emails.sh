#!/usr/bin/env bash
set -euo pipefail
# shellcheck disable=SC1091
source /home/workdir/.grok/skills/resend-api/scripts/load_key.sh
curl -sS 'https://api.resend.com/emails' \
  -H "Authorization: Bearer ${RESEND_API_KEY}"
echo
