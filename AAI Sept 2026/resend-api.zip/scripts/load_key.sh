#!/usr/bin/env bash
# Source this file. Do not execute as a standalone printer.
KEYS="/home/workdir/.grok/skills/resend-api/secrets/keys.env"
if [[ ! -f "$KEYS" ]]; then
  echo "BLOCKED secrets/keys.env missing" >&2
  exit 2
fi
set -a
# shellcheck disable=SC1090
source "$KEYS"
set +a
if [[ -z "${RESEND_API_KEY:-}" || "$RESEND_API_KEY" == "re_xxxxxxxxx" ]]; then
  echo "BLOCKED RESEND_API_KEY missing or placeholder" >&2
  exit 2
fi
