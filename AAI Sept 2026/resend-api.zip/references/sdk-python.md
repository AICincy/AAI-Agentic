# Python SDK samples

Host default is curl. Use these only after `pip install resend` this run.

Replace `re_xxxxxxxxx` with `$RESEND_API_KEY` at runtime. Never paste the live key into this file.

## Send

```python
import os, resend
resend.api_key = os.environ["RESEND_API_KEY"]
email = resend.Emails.send({
    "from": "Acme <onboarding@resend.dev>",
    "to": ["jaredcincy@gmail.com"],
    "subject": "hello world",
    "html": "<p>it works!</p>",
})
print(email)
```

## Batch

```python
import os, resend
resend.api_key = os.environ["RESEND_API_KEY"]
resend.Batch.send([
    {"from": "Acme <onboarding@resend.dev>", "to": ["foo@gmail.com"], "subject": "hello world", "html": "<h1>it works!</h1>"},
    {"from": "Acme <onboarding@resend.dev>", "to": ["bar@outlook.com"], "subject": "world hello", "html": "<p>it works!</p>"},
])
```

## Retrieve / update / cancel / list / attachments / metrics

```python
import os, resend
from datetime import datetime, timedelta
resend.api_key = os.environ["RESEND_API_KEY"]
eid = "0bb1115f-39cd-4e5e-a186-0beaba90f40e"
resend.Emails.get(email_id=eid)
resend.Emails.update({"id": eid, "scheduled_at": (datetime.now() + timedelta(minutes=1)).isoformat()})
resend.Emails.cancel(email_id=eid)
resend.Emails.share(email_id=eid)
resend.Emails.list()
resend.Emails.Attachments.list(email_id=eid)
resend.Emails.metrics({
    "start_date": "2026-07-01",
    "end_date": "2026-07-08",
    "dimensions": ["period", "broadcast"],
})
```
