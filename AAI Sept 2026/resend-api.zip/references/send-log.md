# Send log

| When | Id | To | Subject | Events | Evidence |
| --- | --- | --- | --- | --- | --- |
| 2026-09-09 18:13 UTC | 0bb1115f-39cd-4e5e-a186-0beaba90f40e | jaredcincy@gmail.com | Hello World | sent, delivered | Resend dashboard + curl POST /emails |
