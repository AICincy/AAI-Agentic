# Tool action

Resend is not a first-party Grok connector. The action path is this
skill's scripts plus `secrets/keys.env`.

Synchronous with other subskills

1. AAI recovers the objective and gates.
2. This skill loads in the same turn if Resend is in scope.
3. Scripts run before a second commentary message when send is authorized.
4. Record the JSON `id` or the exact error.
5. Other loaded siblings keep working in that same turn.
6. Do not open a worker, plugin picker, or follow-up menu for the send.

Human gate remains for a new recipient, a new from-address, or any send
Krass did not authorize.
