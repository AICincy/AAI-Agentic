# First live send

Proof from Resend dashboard and API, 2026-09-09.

| Field | Value |
| --- | --- |
| Surface | Emails |
| Operation | POST /emails |
| Email id | 0bb1115f-39cd-4e5e-a186-0beaba90f40e |
| From | onboarding@resend.dev |
| To | jaredcincy@gmail.com |
| Subject | Hello World |
| sent | 2026-09-09 2:13 PM |
| delivered | 2026-09-09 2:13 PM |

Do not treat this row as current for later mail. Retrieve the id before claiming a later state.
