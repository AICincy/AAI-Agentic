---
name: resend-api
description: Sends, retrieves, lists, updates, cancels, and inspects Resend email plus related product surfaces. Use when Krass says Resend, send email, broadcast, template, audience, domain, webhook, or API key for mail. Also use after a live Resend send to record events. AAI subordinate. Never print or commit the live key.
---

# Resend API

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
subordinate mail-route module. It must not override, narrow, suspend, or
reinterpret AAI. Platform and safety rules stay authoritative.

Accept AAI's recovered objective, authorized scope, hard constraints,
authoritative sources, next executable action, completion evidence, and any
human-only gate as control state. Treat Krass corrections as hard constraints
for every affected artifact. Domain status claims stay with AAI.

If `aai-cognitive-interface` is not loaded, say so and stop. Do not
self-govern.

Compose siblings in one turn. Do not spawn agents on this host. Run Resend
scripts in the same turn as other loaded subskills. See
[references/sibling-routing.md](references/sibling-routing.md) and
[references/tool-action.md](references/tool-action.md).

Live send, cancel, update, broadcast, audience write, domain write, webhook
write, and API-key write are human gates unless Krass already authorized that
exact send or change.

Canonical directory: `resend-api`.

When filesystem execution is available, run
`python3 /home/workdir/.grok/skills/aai-cognitive-interface/scripts/aai_runtime_gate.py package <skill-directory>`
after modifying this skill. That is STATIC-PASS only.

## Secrets

Read `/home/workdir/.grok/skills/resend-api/secrets/keys.env`.
Never print the file. Never echo keys. Never put keys in SKILL.md, chat, GitHub, or artifacts.

If the file is missing, say `BLOCKED secrets/keys.env missing` and stop. Do not invent a key. Do not reuse `re_xxxxxxxxx`.

Load

```bash
set -a
# shellcheck disable=SC1091
source /home/workdir/.grok/skills/resend-api/secrets/keys.env
set +a
```

Replace `re_xxxxxxxxx` in any copied SDK sample with `$RESEND_API_KEY` only at runtime.

## Recorded first send

| Field | Value |
| --- | --- |
| Status | delivered |
| Email id | `0bb1115f-39cd-4e5e-a186-0beaba90f40e` |
| From | `onboarding@resend.dev` |
| To | `jaredcincy@gmail.com` |
| Subject | Hello World |
| Log | `POST /emails` |
| Events | sent Sep 09, 2026 2:13 PM; delivered Sep 09, 2026 2:13 PM |
| Route | curl `https://api.resend.com/emails` |

See [references/first-send.md](references/first-send.md).

## Default identity

- From (test): `onboarding@resend.dev`
- To (this account): `jaredcincy@gmail.com`
- Do not change from/to unless Krass names new addresses.

## Execute

Base URL `https://api.resend.com`. Auth `Authorization: Bearer $RESEND_API_KEY`.

Send one email

```bash
bash /home/workdir/.grok/skills/resend-api/scripts/send_email.sh
```

Retrieve the recorded email

```bash
bash /home/workdir/.grok/skills/resend-api/scripts/get_email.sh 0bb1115f-39cd-4e5e-a186-0beaba90f40e
```

List recent emails

```bash
bash /home/workdir/.grok/skills/resend-api/scripts/list_emails.sh
```

Python SDK samples live in [references/sdk-python.md](references/sdk-python.md). Prefer the bash scripts on this host. `python3` here has no `resend` package unless installed this run.

## Product surfaces

Route by the named surface. Read-only first unless write is authorized.

| Surface | Use | Write gate |
| --- | --- | --- |
| Emails | send, batch, get, update, cancel, list, attachments, share, metrics | send/update/cancel |
| Broadcasts | campaign sends | create/send |
| Automations | triggered sequences | create/enable |
| Templates | reusable HTML | create/update |
| Audience | contacts and segments | create/update/delete |
| Metrics | delivery and engagement | none |
| Domains | from-domain auth | add/verify |
| Logs | request and event history | none |
| API keys | auth material | create/revoke |
| Webhooks | event callbacks | create/update |
| Settings | account defaults | update |

If the user names a surface with no local script, call the current Resend HTTP docs, then add a script only when the call will repeat.

## Rules

- Confirm Resend JSON (`id` or documented error). Do not claim sent without an `id`.
- Confirm delivered only from Resend events or a retrieve that shows delivery.
- Append each live send to [references/send-log.md](references/send-log.md).
- If curl returns non-2xx, surface status and body. Do not fake a send.
- The stored key is send-only. GET retrieve/list returned 401 restricted_api_key on 2026-09-09. Use a full-access key for those routes.
- Do not push `secrets/` or a raw key to GitHub.
- Status labels follow AAI. This package may claim DRAFTED or STATIC-PASS only after the matching gate. Do not claim INSTALLED from a local write.

## Stop

- Missing key file.
- Invalid key (`401`).
- Unauthorized live send.
- Resend error body that blocks the named action.
