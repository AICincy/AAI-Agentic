# Sibling Routing

AAI stays in force. This skill maps claims to sources. It does not draft or file.

| Module | When to load | If missing |
| --- | --- | --- |
| aai-cognitive-interface | Every turn | Say the governor is absent. Do not invent AAI labels. |
| forensic-evidentiary-drafting | Court draft after audit | Return the map only. |
| regulatory-complaint-drafting | Agency draft after audit | Keep unsupported claims off the filing draft. |
| authority-currency-auditor | Legal citations | Do not treat a sourced quote as current law. |
| research-execution-briefs | Open-web research claims | Keep open-web incompleteness on the row. |
| personal-context | Prior matter file | Structured retrieval gate. Do not reconstruct. |

`correct_timestamps.py` lives in forensic-evidentiary-drafting. This package only diagnoses offset patterns.
